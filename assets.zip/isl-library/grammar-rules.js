/**
 * SignX - English to ISL (Indian Sign Language) Grammar Converter
 * Implements ISL Linguistic Rules:
 * 1. Multi-word conversational phrase recognition
 * 2. SOV (Subject-Object-Verb) Sentence Structure
 * 3. Wh-Question Word Placement at sentence end (e.g. "Where is station?" -> "TRAIN_STATION WHERE")
 * 4. Copula & stop word elimination ("is", "are", "the", "a")
 * 5. Synonym resolution to verified ISL keyframe clips
 */

import { islDictionary } from './isl-dictionary.js';
import { islVocabulary } from '../avatar/vocabulary/isl-vocabulary.js';
import { logger } from '../utils/logger.js';

// Pre-calibrated Conversational Phrase Matrix
const PHRASE_PATTERNS = [
  { pattern: /thank\s+you(\s+very\s+much|\s+so\s+much|\s+a\s+lot)?/i, glosses: ['THANK_YOU'] },
  { pattern: /thanks(\s+a\s+lot|\s+very\s+much)?/i, glosses: ['THANK_YOU'] },
  { pattern: /hello.*nice\s+to\s+meet\s+you/i, glosses: ['NAMASTE', 'NICE', 'MEET', 'YOU'] },
  { pattern: /nice\s+to\s+meet\s+you/i, glosses: ['NICE', 'MEET', 'YOU'] },
  { pattern: /how\s+are\s+you(\s+today|\s+doing)?/i, glosses: ['HOW', 'ARE', 'YOU'] },
  { pattern: /i\s+love\s+you(\s+friend)?/i, glosses: ['ME', 'LOVE', 'YOU', 'FRIEND'] },
  { pattern: /(can\s+you\s+)?please\s+help\s+me/i, glosses: ['PLEASE', 'HELP', 'ME'] },
  { pattern: /help\s+me(\s+please)?/i, glosses: ['PLEASE', 'HELP', 'ME'] },
  { pattern: /good\s+morning(\s+everyone|\s+all)?/i, glosses: ['GOOD_MORNING'] },
  { pattern: /emergency(\s+assistance|\s+help)?/i, glosses: ['EMERGENCY', 'HELP'] },
  { pattern: /fingerspelling\s+abc(\s+123)?/i, glosses: ['ISL_A', 'ISL_B', 'ISL_C', 'ISL_1', 'ISL_2', 'ISL_3'] },
  { pattern: /where.*train\s+station/i, glosses: ['TRAIN_STATION', 'WHERE'] },
  { pattern: /train\s+station/i, glosses: ['TRAIN_STATION'] },
  { pattern: /water\s+please/i, glosses: ['WATER', 'PLEASE'] },
  { pattern: /my\s+name\s+is/i, glosses: ['MY_NAME'] },
  { pattern: /good\s*bye|see\s+you/i, glosses: ['GOODBYE'] },
  { pattern: /i\s+(need|want)\s+water/i, glosses: ['ME', 'WATER', 'NEED'] },
  { pattern: /i\s+(need|want)\s+help/i, glosses: ['ME', 'HELP', 'NEED'] },
  { pattern: /i\s+(need|want)\s+food/i, glosses: ['ME', 'FOOD', 'NEED'] },
  { pattern: /please\s+give\s+me/i, glosses: ['PLEASE', 'ME', 'GIVE'] },
  { pattern: /i\s+am\s+(happy|glad)/i, glosses: ['ME', 'HAPPY'] },
  { pattern: /i\s+am\s+sad/i, glosses: ['ME', 'SAD'] },
  { pattern: /i\s+am\s+sorry/i, glosses: ['ME', 'SORRY'] },
  { pattern: /go\s+(to\s+)?school/i, glosses: ['SCHOOL', 'GO'] },
  { pattern: /go\s+(to\s+)?home/i, glosses: ['HOME', 'GO'] },
  { pattern: /go\s+(to\s+)?work/i, glosses: ['WORK', 'GO'] },
  { pattern: /come\s+here/i, glosses: ['COME'] },
  { pattern: /i\s+know/i, glosses: ['ME', 'KNOW'] },
  { pattern: /i\s+understand/i, glosses: ['ME', 'UNDERSTAND'] },
  { pattern: /i\s+want\s+to\s+learn/i, glosses: ['ME', 'LEARN', 'WANT'] },
  { pattern: /no\s+thank\s+you/i, glosses: ['NO', 'THANK_YOU'] }
];

const STOP_WORDS = new Set([
  'is', 'am', 'was', 'were', 'be', 'been', 'being',
  'a', 'an', 'the', 'of', 'to', 'in', 'for', 'with', 'on', 'at', 'by', 'from',
  'do', 'does', 'did', 'have', 'has', 'had', 'shall', 'will', 'would', 'could', 'should',
  'very', 'much', 'so', 'lot', 'it', 'its', 'this', 'that', 'these', 'those',
  'just', 'also', 'can', 'and', 'or', 'but', 'not', 'all', 'some', 'any',
  'youtube', 'caption', 'captions', 'live', 'broadcast', 'document', 'extract',
  'available', 'across', 'district', 'science', 'tutorial', 'every', 'each'
]);

const QUESTION_WORDS = new Set([
  'where', 'what', 'who', 'whom', 'whose', 'why', 'how', 'when', 'which'
]);

const TIME_WORDS = new Set([
  'today', 'tomorrow', 'yesterday', 'now', 'morning', 'evening', 'night', 'soon', 'later'
]);

const WORD_TO_ISL_MAP = {
  'thank': 'THANK_YOU',
  'thanks': 'THANK_YOU',
  'hello': 'NAMASTE',
  'hi': 'NAMASTE',
  'hey': 'NAMASTE',
  'namaste': 'NAMASTE',
  'welcome': 'WELCOME',
  'please': 'PLEASE',
  'help': 'HELP',
  'assist': 'HELP',
  'assistance': 'HELP',
  'yes': 'YES',
  'no': 'NO',
  'water': 'WATER',
  'food': 'FOOD',
  'eat': 'FOOD',
  'doctor': 'DOCTOR',
  'hospital': 'DOCTOR',
  'emergency': 'EMERGENCY',
  'station': 'TRAIN_STATION',
  'train': 'TRAIN_STATION',
  'school': 'SCHOOL',
  'study': 'SCHOOL',
  'name': 'MY_NAME',
  'bye': 'GOODBYE',
  'goodbye': 'GOODBYE',
  'you': 'YOU',
  'your': 'YOU',
  'me': 'ME',
  'i': 'ME',
  'my': 'MY_NAME',
  'how': 'HOW',
  'where': 'WHERE',
  'what': 'WHAT',
  'who': 'WHO',
  'are': 'ARE',
  'nice': 'NICE',
  'good': 'NICE',
  'meet': 'MEET',
  'love': 'LOVE',
  'friend': 'FRIEND',
  'give': 'GIVE',
  'need': 'NEED',
  'want': 'WANT',
  'everyone': 'EVERYONE',
  'everybody': 'EVERYONE',
  'come': 'COME',
  'happy': 'HAPPY',
  'glad': 'HAPPY',
  'sad': 'SAD',
  'sorry': 'SORRY',
  'family': 'FAMILY',
  'home': 'HOME',
  'house': 'HOME',
  'work': 'WORK',
  'job': 'WORK',
  'know': 'KNOW',
  'understand': 'UNDERSTAND',
  'learn': 'LEARN',
  'teach': 'TEACH',
  'teacher': 'TEACH',
  'go': 'GO',
  'going': 'GO'
};

export class ISLGrammarConverter {
  /**
   * Convert English sentence/phrase to ISL Gloss Sequence
   * @param {string} sentence 
   * @returns {{ input: string, glossSequence: string[], tokens: object[] }}
   */
  static convert(sentence) {
    if (!sentence || typeof sentence !== 'string') {
      return { input: '', glossSequence: [], tokens: [] };
    }

    // Strip source prefixes from tab demo texts (e.g. "YouTube caption:", "Live Broadcast:", "Document extract:")
    let trimmed = sentence.trim()
      .replace(/^(youtube\s+caption|live\s+broadcast|document\s+extract)\s*:\s*/i, '')
      .trim();

    // 1. Check Pre-calibrated Conversational Phrase Matrix First
    for (const item of PHRASE_PATTERNS) {
      if (item.pattern.test(trimmed)) {
        return {
          input: sentence,
          glossSequence: [...item.glosses],
          isPhraseMatch: true
        };
      }
    }

    // 2. Tokenize & Clean
    const rawWords = trimmed
      .replace(/[^\w\s\?]/g, '')
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);

    let timeTokens = [];
    let questionTokens = [];
    let subjectTokens = [];
    let objectTokens = [];
    let verbTokens = [];
    let otherTokens = [];

    for (let i = 0; i < rawWords.length; i++) {
      const word = rawWords[i].replace('?', '');
      const hasQuestionMark = rawWords[i].includes('?');

      if (hasQuestionMark || QUESTION_WORDS.has(word)) {
        questionTokens.push(WORD_TO_ISL_MAP[word] || word.toUpperCase());
        continue;
      }

      if (TIME_WORDS.has(word)) {
        timeTokens.push(WORD_TO_ISL_MAP[word] || word.toUpperCase());
        continue;
      }

      if (STOP_WORDS.has(word) && !WORD_TO_ISL_MAP[word]) {
        continue; // Skip filler words
      }

      if (WORD_TO_ISL_MAP[word]) {
        const mappedGloss = WORD_TO_ISL_MAP[word];
        if (['YOU', 'ME', 'NAMASTE', 'PLEASE', 'WELCOME', 'EVERYONE'].includes(mappedGloss)) {
          subjectTokens.push(mappedGloss);
        } else if (['WATER', 'FOOD', 'DOCTOR', 'EMERGENCY', 'TRAIN_STATION', 'SCHOOL', 'NICE', 'MEET', 'LOVE', 'FRIEND', 'FAMILY', 'HOME', 'WORK', 'HAPPY', 'SAD'].includes(mappedGloss)) {
          objectTokens.push(mappedGloss);
        } else {
          verbTokens.push(mappedGloss);
        }
        continue;
      }

      // Default: Check vocabulary resolver
      const resolved = islVocabulary.resolve(word);
      if (resolved.found) {
        otherTokens.push(resolved.clipId);
      } else {
        otherTokens.push(word.toUpperCase());
      }
    }

    // 3. Assemble in ISL Natural Order: [TIME] -> [SUBJECT] -> [OBJECT] -> [VERB] -> [QUESTION]
    let sequence = [
      ...timeTokens,
      ...subjectTokens,
      ...objectTokens,
      ...otherTokens,
      ...verbTokens,
      ...questionTokens
    ];

    // Deduplicate consecutive identical tokens
    const deduped = [];
    for (let j = 0; j < sequence.length; j++) {
      if (j === 0 || sequence[j] !== sequence[j - 1]) {
        deduped.push(sequence[j]);
      }
    }

    const finalGlosses = deduped.length > 0 ? deduped : ['NAMASTE'];

    return {
      input: sentence,
      glossSequence: finalGlosses
    };
  }
}
