/**
 * SignX - Camera Stream Manager
 * Manages video stream acquisition, device enumeration, mirroring, and lifecycle.
 */

import { logger } from '../utils/logger.js';

export class CameraManager {
  constructor(videoElement, canvasElement = null) {
    this.video = videoElement;
    this.canvas = canvasElement;
    this.stream = null;
    this.isActive = false;
    this.selectedDeviceId = null;
    this.isMirrored = true;
    this.animationFrameId = null;
    this.listeners = new Map();
  }

  /**
   * Enumerate available video input devices
   */
  async getAvailableDevices() {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
        logger.warn('enumerateDevices not supported in this browser context.');
        return [];
      }
      const devices = await navigator.mediaDevices.enumerateDevices();
      return devices.filter(d => d.kind === 'videoinput');
    } catch (err) {
      logger.error('Failed to list video devices:', err);
      return [];
    }
  }

  /**
   * Start video stream
   */
  async start(deviceId = null) {
    if (this.isActive && this.stream) {
      this.stop();
    }

    this.selectedDeviceId = deviceId;
    const constraints = {
      video: {
        width: { ideal: 640 },
        height: { ideal: 480 },
        frameRate: { ideal: 30 }
      },
      audio: false
    };

    if (deviceId && deviceId !== 'default') {
      constraints.video.deviceId = { exact: deviceId };
    }

    try {
      logger.info('Requesting camera stream with constraints:', constraints);
      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (this.video) {
        this.video.srcObject = this.stream;
        this.video.setAttribute('playsinline', 'true');
        this.video.muted = true;
        
        await this.video.play();
        this.setMirror(this.isMirrored);
      }

      this.isActive = true;
      this.emit('started', { stream: this.stream, deviceId: this.selectedDeviceId });
      logger.info('Camera stream active.');
      return { success: true, stream: this.stream };
    } catch (err) {
      logger.error('Camera access error:', err);
      this.isActive = false;
      this.emit('error', { error: err });
      return { 
        success: false, 
        error: err.name === 'NotAllowedError' ? 'Camera permission was denied' : err.message 
      };
    }
  }

  /**
   * Stop video stream
   */
  stop() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => {
        track.stop();
      });
      this.stream = null;
    }

    if (this.video) {
      this.video.srcObject = null;
    }

    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    this.isActive = false;
    this.emit('stopped');
    logger.info('Camera stream stopped.');
  }

  /**
   * Toggle video mirroring
   */
  setMirror(mirror = true) {
    this.isMirrored = mirror;
    if (this.video) {
      this.video.style.transform = mirror ? 'scaleX(-1)' : 'scaleX(1)';
    }
    if (this.canvas) {
      this.canvas.style.transform = mirror ? 'scaleX(-1)' : 'scaleX(1)';
    }
  }

  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (!this.listeners.has(event)) return;
    const list = this.listeners.get(event).filter(fn => fn !== callback);
    this.listeners.set(event, list);
  }

  emit(event, data) {
    const list = this.listeners.get(event) || [];
    list.forEach(fn => fn(data));
  }
}
