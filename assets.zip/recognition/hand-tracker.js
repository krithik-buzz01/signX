/**
 * SignX - MediaPipe Hand Tracker & Landmark Visualizer
 * Ingests video frames, detects 21 landmarks per hand, and renders skeletal overlay.
 */

import { logger } from '../utils/logger.js';

export const HAND_CONNECTIONS = [
  // Thumb
  [0, 1], [1, 2], [2, 3], [3, 4],
  // Index
  [0, 5], [5, 6], [6, 7], [7, 8],
  // Middle
  [0, 9], [9, 10], [10, 11], [11, 12],
  // Ring
  [0, 13], [13, 14], [14, 15], [15, 16],
  // Pinky
  [0, 17], [17, 18], [18, 19], [19, 20],
  // Palm base
  [5, 9], [9, 13], [13, 17]
];

export class HandTracker {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement ? canvasElement.getContext('2d') : null;
    this.isTracking = false;
    this.showLandmarks = true;
    this.callbacks = new Map();
    this.lastFrameLandmarks = null;
  }

  async init() {
    logger.info('HandTracker initialized.');
    return true;
  }

  setShowLandmarks(enabled) {
    this.showLandmarks = enabled;
    if (!enabled && this.ctx && this.canvas) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }

  /**
   * Draw skeletal landmarks on canvas
   * @param {{ leftHand?: Array, rightHand?: Array }} handsData 
   */
  draw(handsData) {
    if (!this.showLandmarks || !this.ctx || !this.canvas) return;

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    ctx.clearRect(0, 0, w, h);

    if (handsData.leftHand) {
      this.renderHandMesh(ctx, handsData.leftHand, w, h, '#10b981'); // Emerald for Left
    }

    if (handsData.rightHand) {
      this.renderHandMesh(ctx, handsData.rightHand, w, h, '#06b6d4'); // Cyan for Right
    }
  }

  renderHandMesh(ctx, landmarks, w, h, mainColor) {
    if (!landmarks || landmarks.length < 21) return;

    // Draw Bone Connections
    ctx.strokeStyle = mainColor;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    HAND_CONNECTIONS.forEach(([i1, i2]) => {
      const p1 = landmarks[i1];
      const p2 = landmarks[i2];
      if (p1 && p2) {
        ctx.beginPath();
        ctx.moveTo(p1.x * w, p1.y * h);
        ctx.lineTo(p2.x * w, p2.y * h);
        ctx.stroke();
      }
    });

    // Draw Joint Nodes
    landmarks.forEach((p, idx) => {
      ctx.beginPath();
      const isTip = idx === 4 || idx === 8 || idx === 12 || idx === 16 || idx === 20;
      const isWrist = idx === 0;
      const radius = isWrist ? 6 : (isTip ? 4.5 : 3.5);

      ctx.arc(p.x * w, p.y * h, radius, 0, Math.PI * 2);
      ctx.fillStyle = isTip ? '#ffffff' : mainColor;
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });
  }

  /**
   * Dispatch detected frame to recognition pipeline
   */
  dispatchFrame(handsData) {
    this.lastFrameLandmarks = handsData;
    this.draw(handsData);
    
    const list = this.callbacks.get('frame') || [];
    list.forEach(fn => fn(handsData));
  }

  on(event, callback) {
    if (!this.callbacks.has(event)) {
      this.callbacks.set(event, []);
    }
    this.callbacks.get(event).push(callback);
    return () => {
      const arr = this.callbacks.get(event).filter(fn => fn !== callback);
      this.callbacks.set(event, arr);
    };
  }
}
