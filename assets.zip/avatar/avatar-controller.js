/**
 * SignX - Avatar Controller & Structured Command Dispatcher
 * Accepts structured sign commands:
 *   { "sign": "HELLO" }
 *   { "sequence": ["HELLO", "HOW", "ARE", "YOU"] }
 */

import { AVATAR_STATE, AVATAR_EVENTS } from './avatar-state.js';
import { islVocabulary } from './vocabulary/isl-vocabulary.js';
import { AnimationClip } from './animations/animation-clip.js';
import { BASE_POSES } from './gestures/base-poses.js';
import { logger } from '../utils/logger.js';

export class AvatarController {
  constructor(avatarPlayer) {
    this.player = avatarPlayer;
    this.state = AVATAR_STATE.IDLE;
    this.speed = 1.0;
    this.queue = [];
    this.queueIndex = 0;
    this.lastResolvedSequence = [];
    this.listeners = new Map();

    if (this.player) {
      this.player.onClipEnd = (clip) => this.handleClipFinished(clip);
    }
  }

  /**
   * Universal Structured Command Entrypoint
   * @param {{ sign?: string, sequence?: string[], speed?: number }} command 
   */
  async executeCommand(command) {
    if (!command || typeof command !== 'object') {
      logger.warn('Invalid avatar command payload:', command);
      return { success: false, error: 'Invalid command payload' };
    }

    if (command.speed) {
      this.setSpeed(command.speed);
    }

    if (command.sign) {
      return this.playSign(command.sign);
    }

    if (Array.isArray(command.sequence)) {
      return this.playSequence(command.sequence);
    }

    return { success: false, error: 'Command must provide "sign" or "sequence"' };
  }

  /**
   * Play a single sign by name or token
   */
  async playSign(signName) {
    return this.playSequence([signName]);
  }

  /**
   * Play a sequence of signs with automatic smooth transitions
   * @param {string[]} signNames 
   */
  async playSequence(signNames) {
    if (!Array.isArray(signNames) || signNames.length === 0) {
      this.stop();
      return { success: false, message: 'Sequence is empty' };
    }

    logger.info('Avatar playing sequence:', signNames);

    this.lastResolvedSequence = [...signNames];
    this.queue = islVocabulary.resolveSequence(signNames);
    this.queueIndex = 0;

    this.setState(AVATAR_STATE.PLAYING);
    this.emit(AVATAR_EVENTS.SEQUENCE_START, { 
      total: this.queue.length, 
      items: this.queue 
    });

    this.player.start();
    this.playNextInQueue();
    return { success: true, count: this.queue.length };
  }

  playNextInQueue() {
    if (this.state !== AVATAR_STATE.PLAYING) return;

    if (this.queueIndex >= this.queue.length) {
      this.finishSequence();
      return;
    }

    const currentItem = this.queue[this.queueIndex];

    if (!currentItem.found) {
      // Strictly handle "Sign not available" fallback
      logger.warn(`ISL Sign not available in verified dictionary: "${currentItem.token}"`);
      this.setState(AVATAR_STATE.SIGN_UNAVAILABLE);
      this.player.setUnavailableSign(currentItem.token);
      
      this.emit(AVATAR_EVENTS.SIGN_NOT_FOUND, { 
        token: currentItem.token, 
        index: this.queueIndex, 
        total: this.queue.length 
      });

      // Display unavailable banner for a clear interval, then proceed
      const fallbackDisplayDuration = 1400 / this.speed;
      setTimeout(() => {
        if (this.state === AVATAR_STATE.SIGN_UNAVAILABLE || this.state === AVATAR_STATE.PLAYING) {
          this.setState(AVATAR_STATE.PLAYING);
          this.queueIndex++;
          this.playNextInQueue();
        }
      }, fallbackDisplayDuration);
      return;
    }

    // Play verified clip
    const clip = currentItem.clip;
    this.emit(AVATAR_EVENTS.SIGN_START, {
      token: currentItem.token,
      clipId: currentItem.clipId,
      name: clip.name,
      index: this.queueIndex,
      total: this.queue.length
    });

    this.player.setClip(clip, clip.name);
  }

  handleClipFinished(finishedClip) {
    if (this.state !== AVATAR_STATE.PLAYING) return;

    // If the clip that just finished was a transition blend,
    // we should now play the ACTUAL sign at the current queueIndex — 
    // do NOT increment the index.
    if (finishedClip.id === 'TRANSITION' || finishedClip.name === 'Transitioning...' || this._isTransitionPlaying) {
      this._isTransitionPlaying = false;
      this.playNextInQueue();
      return;
    }

    this.emit(AVATAR_EVENTS.SIGN_END, {
      clipId: finishedClip.id,
      index: this.queueIndex
    });

    this.queueIndex++;

    if (this.queueIndex < this.queue.length) {
      // Smooth transitional blend to next sign
      const nextItem = this.queue[this.queueIndex];
      if (nextItem.found && nextItem.clip) {
        const fromPose = this.player.currentPose;
        const toPose = nextItem.clip.keyframes[0]?.pose || BASE_POSES.NEUTRAL_REST;
        const transition = AnimationClip.createTransition(fromPose, toPose, 180 / this.speed);
        
        this._isTransitionPlaying = true;
        this.player.setClip(transition, '...');
        return; // handleClipFinished will fire again for the transition
      }
    }

    this.playNextInQueue();
  }

  finishSequence() {
    this.setState(AVATAR_STATE.IDLE);
    this.player.setClip(null, 'READY');
    this.emit(AVATAR_EVENTS.SEQUENCE_COMPLETE);
    logger.info('Avatar sequence completed.');
  }

  pause() {
    if (this.state === AVATAR_STATE.PLAYING) {
      this.setState(AVATAR_STATE.PAUSED);
      this.player.stop();
    }
  }

  resume() {
    if (this.state === AVATAR_STATE.PAUSED) {
      this.setState(AVATAR_STATE.PLAYING);
      this.player.start();
    }
  }

  stop() {
    this.setState(AVATAR_STATE.STOPPED);
    this.queue = [];
    this.queueIndex = 0;
    this.player.setClip(null, 'IDLE');
    this.player.currentPose = { ...BASE_POSES.NEUTRAL_REST };
  }

  replay() {
    if (this.lastResolvedSequence.length > 0) {
      this.playSequence(this.lastResolvedSequence);
    }
  }

  setSpeed(speed) {
    this.speed = Math.max(0.25, Math.min(3.0, Number(speed) || 1.0));
    this.player.setSpeed(this.speed);
    this.emit(AVATAR_EVENTS.SPEED_CHANGE, { speed: this.speed });
  }

  setState(newState) {
    if (this.state !== newState) {
      const oldState = this.state;
      this.state = newState;
      this.emit(AVATAR_EVENTS.STATE_CHANGE, { state: newState, oldState });
    }
  }

  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
    return () => {
      const arr = this.listeners.get(event).filter(fn => fn !== callback);
      this.listeners.set(event, arr);
    };
  }

  emit(event, data) {
    const list = this.listeners.get(event) || [];
    list.forEach(fn => fn(data));
  }
}
