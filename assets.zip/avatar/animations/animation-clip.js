/**
 * SignX - Animation Clip Structure & Smooth Keyframe Interpolator
 */

import { ISL_HANDSHAPES } from '../gestures/handshapes.js';
import { BASE_POSES } from '../gestures/base-poses.js';

export class AnimationClip {
  /**
   * @param {string} id - Unique identifier (e.g., 'NAMASTE', 'ISL_A')
   * @param {string} name - Display name
   * @param {number} durationMs - Total clip duration in milliseconds
   * @param {Array<{t: number, pose: object, leftHand?: string, rightHand?: string}>} keyframes
   */
  constructor(id, name, durationMs, keyframes) {
    this.id = id;
    this.name = name;
    this.durationMs = durationMs;
    // Sort keyframes by time normalized 0..1
    this.keyframes = [...keyframes].sort((a, b) => a.t - b.t);
  }

  /**
   * Sample interpolated pose at normalized progress (0.0 to 1.0)
   * @param {number} progress 
   * @returns {object} interpolated pose with handshapes
   */
  sample(progress) {
    const p = Math.max(0, Math.min(1, progress));
    if (this.keyframes.length === 0) return BASE_POSES.NEUTRAL_REST;
    if (this.keyframes.length === 1) return this.resolvePose(this.keyframes[0]);

    // Find bounding keyframes
    let k0 = this.keyframes[0];
    let k1 = this.keyframes[this.keyframes.length - 1];

    for (let i = 0; i < this.keyframes.length - 1; i++) {
      if (p >= this.keyframes[i].t && p <= this.keyframes[i + 1].t) {
        k0 = this.keyframes[i];
        k1 = this.keyframes[i + 1];
        break;
      }
    }

    const span = k1.t - k0.t;
    const localT = span > 0 ? (p - k0.t) / span : 0;
    // Cubic smoothstep easing: 3t^2 - 2t^3
    const easedT = localT * localT * (3 - 2 * localT);

    const pose0 = this.resolvePose(k0);
    const pose1 = this.resolvePose(k1);

    return this.interpolatePoses(pose0, pose1, easedT);
  }

  resolvePose(kf) {
    let base = kf.pose;
    if (typeof base === 'string') {
      base = BASE_POSES[base] || BASE_POSES.NEUTRAL_REST;
    }
    return {
      head: base.head || { pitch: 0, yaw: 0, roll: 0 },
      torso: base.torso || { x: 0, y: 0, z: 0, lean: 0 },
      leftArm: base.leftArm || BASE_POSES.NEUTRAL_REST.leftArm,
      rightArm: base.rightArm || BASE_POSES.NEUTRAL_REST.rightArm,
      leftHand: kf.leftHand || base.leftHand || 'OPEN_FLAT',
      rightHand: kf.rightHand || base.rightHand || 'OPEN_FLAT'
    };
  }

  interpolatePoses(p0, p1, t) {
    const lerp = (a, b) => (a || 0) + ((b || 0) - (a || 0)) * t;

    const interpolated = {
      head: {
        pitch: lerp(p0.head.pitch, p1.head.pitch),
        yaw: lerp(p0.head.yaw, p1.head.yaw),
        roll: lerp(p0.head.roll, p1.head.roll)
      },
      torso: {
        x: lerp(p0.torso.x, p1.torso.x),
        y: lerp(p0.torso.y, p1.torso.y),
        z: lerp(p0.torso.z, p1.torso.z),
        lean: lerp(p0.torso.lean, p1.torso.lean)
      },
      leftArm: {
        shoulderX: lerp(p0.leftArm.shoulderX, p1.leftArm.shoulderX),
        shoulderY: lerp(p0.leftArm.shoulderY, p1.leftArm.shoulderY),
        elbowX: lerp(p0.leftArm.elbowX, p1.leftArm.elbowX),
        elbowY: lerp(p0.leftArm.elbowY, p1.leftArm.elbowY),
        wristX: lerp(p0.leftArm.wristX, p1.leftArm.wristX),
        wristY: lerp(p0.leftArm.wristY, p1.leftArm.wristY),
        rotation: lerp(p0.leftArm.rotation, p1.leftArm.rotation)
      },
      rightArm: {
        shoulderX: lerp(p0.rightArm.shoulderX, p1.rightArm.shoulderX),
        shoulderY: lerp(p0.rightArm.shoulderY, p1.rightArm.shoulderY),
        elbowX: lerp(p0.rightArm.elbowX, p1.rightArm.elbowX),
        elbowY: lerp(p0.rightArm.elbowY, p1.rightArm.elbowY),
        wristX: lerp(p0.rightArm.wristX, p1.rightArm.wristX),
        wristY: lerp(p0.rightArm.wristY, p1.rightArm.wristY),
        rotation: lerp(p0.rightArm.rotation, p1.rightArm.rotation)
      },
      leftHand: this.interpolateHandshape(p0.leftHand, p1.leftHand, t),
      rightHand: this.interpolateHandshape(p0.rightHand, p1.rightHand, t)
    };

    return interpolated;
  }

  interpolateHandshape(h0Key, h1Key, t) {
    const h0 = ISL_HANDSHAPES[h0Key] || ISL_HANDSHAPES.OPEN_FLAT;
    const h1 = ISL_HANDSHAPES[h1Key] || ISL_HANDSHAPES.OPEN_FLAT;

    const lerp = (a, b) => a + (b - a) * t;

    const flexion = h0.flexion.map((f, i) => lerp(f, h1.flexion[i]));
    const spread = h0.spread.map((s, i) => lerp(s, h1.spread[i]));

    return {
      name: t < 0.5 ? h0.name : h1.name,
      flexion,
      spread,
      crossed: Boolean(h1.crossed || h0.crossed)
    };
  }

  /**
   * Create smooth transition clip between two static poses
   */
  static createTransition(fromPose, toPose, durationMs = 220) {
    return new AnimationClip(
      'TRANSITION',
      'Transitioning...',
      durationMs,
      [
        { t: 0.0, pose: fromPose },
        { t: 1.0, pose: toPose }
      ]
    );
  }
}
