/**
 * SignX - Predefined Verified Indian Sign Language (ISL) Keyframe Animation Clips
 */

import { AnimationClip } from './animation-clip.js';
import { BASE_POSES } from '../gestures/base-poses.js';

export const ISL_CLIPS = new Map();

function registerClip(id, name, durationMs, keyframes) {
  const clip = new AnimationClip(id, name, durationMs, keyframes);
  ISL_CLIPS.set(id, clip);
  return clip;
}

/* ================= 1. CORE VOCABULARY CLIPS ================= */

// NAMASTE / HELLO
registerClip('NAMASTE', 'Namaste / Hello', 1400, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { t: 0.3, pose: BASE_POSES.PRAYER_CHEST, leftHand: 'PRAYER', rightHand: 'PRAYER' },
  { 
    t: 0.65, 
    pose: {
      ...BASE_POSES.PRAYER_CHEST,
      head: { pitch: 0.16, yaw: 0, roll: 0 },
      torso: { x: 0, y: -0.04, z: 0, lean: 0.12 }
    },
    leftHand: 'PRAYER',
    rightHand: 'PRAYER'
  },
  { t: 0.85, pose: BASE_POSES.PRAYER_CHEST, leftHand: 'PRAYER', rightHand: 'PRAYER' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// THANK YOU
registerClip('THANK_YOU', 'Thank You', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { t: 0.35, pose: BASE_POSES.CHIN_TOUCH, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { t: 0.75, pose: BASE_POSES.FORWARD_OUT, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// WELCOME
registerClip('WELCOME', 'Welcome', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.40, elbowY: 0.15, wristX: 0.32, wristY: 0.18, rotation: -0.4 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.04, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.05, wristY: 0.12, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// PLEASE
registerClip('PLEASE', 'Please', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.12, wristX: 0.04, wristY: 0.18, rotation: 0.1 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.55, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.10, wristX: -0.04, wristY: 0.14, rotation: 0.1 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.8, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.12, wristX: 0.04, wristY: 0.18, rotation: 0.1 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// YES (Nodding fist)
registerClip('YES', 'Yes', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'FIST' },
  { t: 0.25, pose: BASE_POSES.FIST_NOD_HIGH, rightHand: 'FIST' },
  { t: 0.5, pose: BASE_POSES.FIST_NOD_LOW, rightHand: 'FIST' },
  { t: 0.75, pose: BASE_POSES.FIST_NOD_HIGH, rightHand: 'FIST' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// NO (Side wagging index)
registerClip('NO', 'No', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.25, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0, yaw: -0.08, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.12, wristX: 0.12, wristY: 0.24, rotation: 0.2 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.5, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0, yaw: 0.08, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.12, wristX: 0.26, wristY: 0.24, rotation: -0.2 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0, yaw: -0.08, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.12, wristX: 0.12, wristY: 0.24, rotation: 0.2 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// HELP (Fist lifted on flat palm)
registerClip('HELP', 'Help', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'FIST' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.02, rotation: 0.3 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.08, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'THUMBS_UP'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.15, wristX: 0.0, wristY: 0.22, rotation: 0.3 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.15, wristX: 0.0, wristY: 0.28, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'THUMBS_UP'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// WHERE (Both palms open side-to-side)
registerClip('WHERE', 'Where', 1400, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'CUPPED', rightHand: 'CUPPED' },
  { t: 0.3, pose: BASE_POSES.PALMS_UP_SPREAD, leftHand: 'CUPPED', rightHand: 'CUPPED' },
  { 
    t: 0.6, 
    pose: {
      ...BASE_POSES.PALMS_UP_SPREAD,
      head: { pitch: -0.06, yaw: 0.06, roll: 0.04 },
      leftArm: { ...BASE_POSES.PALMS_UP_SPREAD.leftArm, wristX: -0.28 },
      rightArm: { ...BASE_POSES.PALMS_UP_SPREAD.rightArm, wristX: 0.28 }
    },
    leftHand: 'CUPPED',
    rightHand: 'CUPPED'
  },
  { t: 0.85, pose: BASE_POSES.PALMS_UP_SPREAD, leftHand: 'CUPPED', rightHand: 'CUPPED' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// WHAT
registerClip('WHAT', 'What', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: -0.05, yaw: 0.04, roll: 0.03 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.26, elbowY: 0.12, wristX: 0.18, wristY: 0.26, rotation: 0.2 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: -0.05, yaw: -0.04, roll: -0.03 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.26, elbowY: 0.12, wristX: 0.24, wristY: 0.26, rotation: -0.2 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// WHO (Circle chin)
registerClip('WHO', 'Who', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.14, wristX: 0.04, wristY: 0.28, rotation: 0.3 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.14, wristX: -0.02, wristY: 0.32, rotation: 0.3 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// HOW
registerClip('HOW', 'How', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'CUPPED', rightHand: 'CUPPED' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.08, wristX: -0.06, wristY: 0.14, rotation: -0.6 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.08, wristX: 0.06, wristY: 0.14, rotation: 0.6 }
    },
    leftHand: 'CUPPED',
    rightHand: 'CUPPED'
  },
  { t: 0.75, pose: BASE_POSES.PALMS_UP_SPREAD, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// GOOD_MORNING (Compound: Good + Morning)
registerClip('GOOD_MORNING', 'Good Morning', 1600, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'THUMBS_UP' },
  { t: 0.3, pose: BASE_POSES.CHIN_TOUCH, rightHand: 'THUMBS_UP' },
  { t: 0.55, pose: BASE_POSES.FORWARD_OUT, rightHand: 'THUMBS_UP' },
  { 
    t: 0.85, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.05, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.22, wristX: 0.20, wristY: 0.42, rotation: 0.2 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// WATER
registerClip('WATER', 'Water', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_W' },
  { t: 0.35, pose: BASE_POSES.MOUTH_NEAR, rightHand: 'ISL_W' },
  { 
    t: 0.55, 
    pose: {
      ...BASE_POSES.MOUTH_NEAR,
      rightArm: { ...BASE_POSES.MOUTH_NEAR.rightArm, wristX: 0.12 }
    },
    rightHand: 'ISL_W'
  },
  { t: 0.75, pose: BASE_POSES.MOUTH_NEAR, rightHand: 'ISL_W' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// FOOD / EAT
registerClip('FOOD', 'Food / Eat', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_O' },
  { t: 0.35, pose: BASE_POSES.MOUTH_NEAR, rightHand: 'ISL_O' },
  { 
    t: 0.55, 
    pose: {
      ...BASE_POSES.MOUTH_NEAR,
      rightArm: { ...BASE_POSES.MOUTH_NEAR.rightArm, wristY: 0.28 }
    },
    rightHand: 'ISL_O'
  },
  { t: 0.75, pose: BASE_POSES.MOUTH_NEAR, rightHand: 'ISL_O' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// DOCTOR (Pulse tap)
registerClip('DOCTOR', 'Doctor', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'ISL_U' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.08, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.0, wristY: 0.12, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_U'
  },
  { 
    t: 0.55, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.08, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.0, wristY: 0.18, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_U'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.05, wristX: 0.0, wristY: 0.08, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.0, wristY: 0.12, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_U'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// EMERGENCY (E waving)
registerClip('EMERGENCY', 'Emergency', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_E' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.04, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.15, wristX: 0.20, wristY: 0.32, rotation: 0.2 }
    },
    rightHand: 'ISL_E'
  },
  { 
    t: 0.5, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.15, wristX: 0.28, wristY: 0.32, rotation: -0.2 }
    },
    rightHand: 'ISL_E'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.15, wristX: 0.20, wristY: 0.32, rotation: 0.2 }
    },
    rightHand: 'ISL_E'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// TRAIN_STATION
registerClip('TRAIN_STATION', 'Train Station', 1500, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'ISL_H', rightHand: 'ISL_H' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.05, wristY: 0.12, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: -0.05, wristY: 0.16, rotation: 0 }
    },
    leftHand: 'ISL_H',
    rightHand: 'ISL_H'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.05, wristY: 0.12, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.26, elbowY: 0.08, wristX: 0.15, wristY: 0.16, rotation: 0 }
    },
    leftHand: 'ISL_H',
    rightHand: 'ISL_H'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// SCHOOL / STUDY
registerClip('SCHOOL', 'School / Study', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.05, wristX: -0.02, wristY: 0.10, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.04, wristY: 0.22, rotation: 0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.5, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.05, wristX: -0.02, wristY: 0.10, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.06, wristX: -0.02, wristY: 0.12, rotation: 0.0 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.05, wristX: -0.02, wristY: 0.10, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.04, wristY: 0.22, rotation: 0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// MY_NAME
registerClip('MY_NAME', 'My Name', 1400, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.02, wristY: 0.16, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.03, wristY: 0.16, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.03, wristY: 0.16, rotation: 0 }
    },
    leftHand: 'ISL_H',
    rightHand: 'ISL_H'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// GOODBYE (Wave)
registerClip('GOODBYE', 'Goodbye', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_B' },
  { t: 0.25, pose: BASE_POSES.HIGH_WAVE_L, rightHand: 'ISL_B' },
  { t: 0.5, pose: BASE_POSES.HIGH_WAVE_R, rightHand: 'ISL_B' },
  { t: 0.75, pose: BASE_POSES.HIGH_WAVE_L, rightHand: 'ISL_B' },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

/* ================= 2. ISL SINGLE HAND ALPHABET CLIPS (A - Z) ================= */
'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(char => {
  const handshapeKey = `ISL_${char}`;
  registerClip(handshapeKey, `ISL Letter ${char}`, 1000, [
    { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: handshapeKey },
    { 
      t: 0.35, 
      pose: {
        ...BASE_POSES.NEUTRAL_REST,
        rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.14, wristX: 0.18, wristY: 0.26, rotation: 0.0 }
      },
      rightHand: handshapeKey
    },
    { 
      t: 0.75, 
      pose: {
        ...BASE_POSES.NEUTRAL_REST,
        rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.14, wristX: 0.18, wristY: 0.26, rotation: 0.0 }
      },
      rightHand: handshapeKey
    },
    { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
  ]);
});


/* ================= 3. CONVERSATIONAL & PHRASE CLIPS ================= */

// YOU (Pointing forward)
registerClip('YOU', 'You', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.08, wristY: 0.20, rotation: 0.1 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.08, wristY: 0.22, rotation: 0.1 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// ME / I (Self point to chest)
registerClip('ME', 'Me / I', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.08, wristX: 0.02, wristY: 0.12, rotation: 0.4 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);
registerClip('I', 'I', 1100, ISL_CLIPS.get('ME').keyframes);

// ARE (Held open palm)
registerClip('ARE', 'Are', 1000, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.26, elbowY: 0.12, wristX: 0.16, wristY: 0.18, rotation: 0.0 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// NICE (Smooth flat wipe)
registerClip('NICE', 'Nice', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.06, wristX: 0.0, wristY: 0.10, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: -0.06, wristY: 0.12, rotation: 0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.06, wristX: 0.0, wristY: 0.10, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.08, wristX: 0.10, wristY: 0.12, rotation: 0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// MEET (Two approaching index fingers)
registerClip('MEET', 'Meet', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'POINT', rightHand: 'POINT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.10, wristX: -0.08, wristY: 0.18, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.10, wristX: 0.08, wristY: 0.18, rotation: -0.2 }
    },
    leftHand: 'POINT',
    rightHand: 'POINT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.10, wristX: -0.02, wristY: 0.18, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.02, wristY: 0.18, rotation: -0.1 }
    },
    leftHand: 'POINT',
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// LOVE (Arms crossed over heart)
registerClip('LOVE', 'Love', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'FIST', rightHand: 'FIST' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.16, elbowY: 0.12, wristX: 0.12, wristY: 0.18, rotation: 0.4 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.16, elbowY: 0.12, wristX: -0.12, wristY: 0.18, rotation: -0.4 }
    },
    leftHand: 'FIST',
    rightHand: 'FIST'
  },
  { 
    t: 0.8, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.06, yaw: 0, roll: 0 },
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.16, elbowY: 0.12, wristX: 0.12, wristY: 0.18, rotation: 0.4 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.16, elbowY: 0.12, wristX: -0.12, wristY: 0.18, rotation: -0.4 }
    },
    leftHand: 'FIST',
    rightHand: 'FIST'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// FRIEND (Interlocked index gestures)
registerClip('FRIEND', 'Friend', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'ISL_X', rightHand: 'ISL_X' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.02, wristY: 0.16, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.02, wristY: 0.16, rotation: -0.2 }
    },
    leftHand: 'ISL_X',
    rightHand: 'ISL_X'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// Numbers 1, 2, 3
registerClip('ISL_1', 'Number 1', 1000, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.14, wristX: 0.20, wristY: 0.28, rotation: 0.0 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

registerClip('ISL_2', 'Number 2', 1000, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_V' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.14, wristX: 0.20, wristY: 0.28, rotation: 0.0 }
    },
    rightHand: 'ISL_V'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

registerClip('ISL_3', 'Number 3', 1000, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_W' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.30, elbowY: 0.14, wristX: 0.20, wristY: 0.28, rotation: 0.0 }
    },
    rightHand: 'ISL_W'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

/* ================= 4. COMMON VERBS & NOUNS ================= */

// GIVE (Both hands pushing outward together)
registerClip('GIVE', 'Give', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.04, wristY: 0.14, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.04, wristY: 0.14, rotation: -0.2 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.12, wristX: -0.10, wristY: 0.22, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.10, wristY: 0.22, rotation: -0.2 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// NEED (Bent right index pulling downward)
registerClip('NEED', 'Need', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_X' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.10, wristY: 0.22, rotation: 0.3 }
    },
    rightHand: 'ISL_X'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.04, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.08, wristX: 0.10, wristY: 0.14, rotation: 0.3 }
    },
    rightHand: 'ISL_X'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// EVERYONE (Sweeping point across)
registerClip('EVERYONE', 'Everyone', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.12, wristX: -0.08, wristY: 0.22, rotation: 0.1 }
    },
    rightHand: 'POINT'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.28, elbowY: 0.12, wristX: 0.22, wristY: 0.22, rotation: -0.1 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// COME (Beckoning gesture inward)
registerClip('COME', 'Come', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'POINT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.26, elbowY: 0.12, wristX: 0.16, wristY: 0.22, rotation: 0.0 }
    },
    rightHand: 'CUPPED'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.04, wristY: 0.14, rotation: 0.3 }
    },
    rightHand: 'CUPPED'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// HAPPY (Flat hand brushing upward on chest)
registerClip('HAPPY', 'Happy', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.06, wristX: 0.02, wristY: 0.08, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.04, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.14, wristX: 0.04, wristY: 0.22, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// SAD (Both flat hands sliding down the face)
registerClip('SAD', 'Sad', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.20, elbowY: 0.12, wristX: -0.04, wristY: 0.28, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.12, wristX: 0.04, wristY: 0.28, rotation: -0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.10, yaw: 0, roll: 0 },
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.20, elbowY: 0.08, wristX: -0.04, wristY: 0.14, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.08, wristX: 0.04, wristY: 0.14, rotation: -0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// SORRY (Fist circling on chest)
registerClip('SORRY', 'Sorry', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'FIST' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.08, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.06, wristX: -0.02, wristY: 0.10, rotation: 0.4 }
    },
    rightHand: 'FIST'
  },
  { 
    t: 0.6, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.08, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.06, wristY: 0.14, rotation: 0.4 }
    },
    rightHand: 'FIST'
  },
  { 
    t: 0.85, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      head: { pitch: 0.08, yaw: 0, roll: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.06, wristX: -0.02, wristY: 0.10, rotation: 0.4 }
    },
    rightHand: 'FIST'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// FAMILY (Both F-hands circling outward)
registerClip('FAMILY', 'Family', 1400, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'ISL_F', rightHand: 'ISL_F' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.10, wristX: -0.06, wristY: 0.18, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.06, wristY: 0.18, rotation: -0.2 }
    },
    leftHand: 'ISL_F',
    rightHand: 'ISL_F'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.10, wristX: -0.14, wristY: 0.18, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.10, wristX: 0.14, wristY: 0.18, rotation: -0.2 }
    },
    leftHand: 'ISL_F',
    rightHand: 'ISL_F'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// HOME (Touching cheek then moving to temple)
registerClip('HOME', 'Home', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'ISL_O' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.12, wristX: 0.06, wristY: 0.26, rotation: 0.2 }
    },
    rightHand: 'ISL_O'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.14, wristX: 0.10, wristY: 0.30, rotation: 0.2 }
    },
    rightHand: 'ISL_O'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// WORK (Both fists tapping downward)
registerClip('WORK', 'Work', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'FIST', rightHand: 'FIST' },
  { 
    t: 0.3, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.06, wristX: -0.02, wristY: 0.10, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.02, wristY: 0.18, rotation: 0 }
    },
    leftHand: 'FIST',
    rightHand: 'FIST'
  },
  { 
    t: 0.55, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.06, wristX: -0.02, wristY: 0.10, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.08, wristX: 0.02, wristY: 0.12, rotation: 0 }
    },
    leftHand: 'FIST',
    rightHand: 'FIST'
  },
  { 
    t: 0.8, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.06, wristX: -0.02, wristY: 0.10, rotation: 0 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.02, wristY: 0.18, rotation: 0 }
    },
    leftHand: 'FIST',
    rightHand: 'FIST'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// WANT (Both cupped hands pulling inward)
registerClip('WANT', 'Want', 1200, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'CUPPED', rightHand: 'CUPPED' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.10, wristX: -0.10, wristY: 0.18, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.10, wristX: 0.10, wristY: 0.18, rotation: -0.2 }
    },
    leftHand: 'CUPPED',
    rightHand: 'CUPPED'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.08, wristX: -0.04, wristY: 0.12, rotation: 0.3 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.08, wristX: 0.04, wristY: 0.12, rotation: -0.3 }
    },
    leftHand: 'CUPPED',
    rightHand: 'CUPPED'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// KNOW (Fingers tapping forehead)
registerClip('KNOW', 'Know', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.14, wristX: 0.06, wristY: 0.32, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { 
    t: 0.7, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.16, wristX: 0.06, wristY: 0.36, rotation: 0.2 }
    },
    rightHand: 'OPEN_FLAT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// UNDERSTAND (Fist opening at forehead — lightbulb gesture)
registerClip('UNDERSTAND', 'Understand', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'FIST' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.14, wristX: 0.06, wristY: 0.32, rotation: 0.2 }
    },
    rightHand: 'FIST'
  },
  { 
    t: 0.65, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.16, wristX: 0.06, wristY: 0.36, rotation: 0.2 }
    },
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, rightHand: 'OPEN_FLAT' }
]);

// LEARN (Scooping hand from book to forehead)
registerClip('LEARN', 'Learn', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'CUPPED' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.05, wristX: -0.02, wristY: 0.10, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.06, wristX: -0.02, wristY: 0.12, rotation: 0.1 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'CUPPED'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.05, wristX: -0.02, wristY: 0.10, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.16, wristX: 0.06, wristY: 0.34, rotation: 0.2 }
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'CUPPED'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// TEACH (Both O-hands moving outward from forehead)
registerClip('TEACH', 'Teach', 1300, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'ISL_O', rightHand: 'ISL_O' },
  { 
    t: 0.35, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.20, elbowY: 0.14, wristX: -0.04, wristY: 0.28, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.20, elbowY: 0.14, wristX: 0.04, wristY: 0.28, rotation: -0.1 }
    },
    leftHand: 'ISL_O',
    rightHand: 'ISL_O'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.12, wristX: -0.12, wristY: 0.22, rotation: 0.2 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.12, wristY: 0.22, rotation: -0.2 }
    },
    leftHand: 'ISL_O',
    rightHand: 'ISL_O'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

// GO (Both index fingers flicking outward)
registerClip('GO', 'Go', 1100, [
  { t: 0.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'POINT', rightHand: 'POINT' },
  { 
    t: 0.4, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.22, elbowY: 0.10, wristX: -0.06, wristY: 0.18, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.22, elbowY: 0.10, wristX: 0.06, wristY: 0.18, rotation: -0.1 }
    },
    leftHand: 'POINT',
    rightHand: 'POINT'
  },
  { 
    t: 0.75, 
    pose: {
      ...BASE_POSES.NEUTRAL_REST,
      leftArm: { shoulderX: -0.32, shoulderY: 0.28, elbowX: -0.24, elbowY: 0.12, wristX: -0.14, wristY: 0.22, rotation: 0.1 },
      rightArm: { shoulderX: 0.32, shoulderY: 0.28, elbowX: 0.24, elbowY: 0.12, wristX: 0.14, wristY: 0.22, rotation: -0.1 }
    },
    leftHand: 'POINT',
    rightHand: 'POINT'
  },
  { t: 1.0, pose: BASE_POSES.NEUTRAL_REST, leftHand: 'OPEN_FLAT', rightHand: 'OPEN_FLAT' }
]);

/* ================= 5. DIRECT WORD ALIASES FOR NATURAL RESOLUTION ================= */
registerClip('THANK', 'Thank You', 1200, ISL_CLIPS.get('THANK_YOU').keyframes);
registerClip('THANKS', 'Thank You', 1200, ISL_CLIPS.get('THANK_YOU').keyframes);
registerClip('HELLO', 'Hello / Namaste', 1400, ISL_CLIPS.get('NAMASTE').keyframes);
registerClip('HI', 'Hi / Namaste', 1400, ISL_CLIPS.get('NAMASTE').keyframes);
registerClip('GREETINGS', 'Greetings', 1400, ISL_CLIPS.get('NAMASTE').keyframes);
registerClip('ASSIST', 'Assist / Help', 1300, ISL_CLIPS.get('HELP').keyframes);
registerClip('ASSISTANCE', 'Assistance / Help', 1300, ISL_CLIPS.get('HELP').keyframes);
registerClip('TRAIN', 'Train', 1500, ISL_CLIPS.get('TRAIN_STATION').keyframes);
registerClip('STATION', 'Station', 1500, ISL_CLIPS.get('TRAIN_STATION').keyframes);
registerClip('HOSPITAL', 'Hospital / Doctor', 1300, ISL_CLIPS.get('DOCTOR').keyframes);
registerClip('EAT', 'Eat / Food', 1200, ISL_CLIPS.get('FOOD').keyframes);
registerClip('BYE', 'Goodbye', 1300, ISL_CLIPS.get('GOODBYE').keyframes);
registerClip('STUDY', 'Study / School', 1300, ISL_CLIPS.get('SCHOOL').keyframes);
registerClip('GOOD', 'Good', 1200, ISL_CLIPS.get('NICE').keyframes);
registerClip('ALL', 'Everyone', 1300, ISL_CLIPS.get('EVERYONE').keyframes);
