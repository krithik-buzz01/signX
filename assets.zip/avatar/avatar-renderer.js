/**
 * SignX - Avatar Visual Renderer
 * Renders an accessible, stylized avatar on HTML5 Canvas.
 * Supports smooth procedural idle animation, hand gesturing, and ready hooks for 3D Three.js models.
 */

export class AvatarRenderer {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement ? canvasElement.getContext('2d') : null;
    this.animationFrameId = null;
    this.isRunning = false;
    this.currentGloss = null;
    this.progress = 0; // 0 to 1
    this.startTime = Date.now();
    this.avatarColor = '#38bdf8';
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.startTime = Date.now();
    this.loop();
  }

  stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  setGloss(gloss, progress = 0) {
    this.currentGloss = gloss;
    this.progress = progress;
  }

  loop() {
    if (!this.isRunning) return;

    this.render();
    this.animationFrameId = requestAnimationFrame(() => this.loop());
  }

  render() {
    if (!this.ctx || !this.canvas) return;

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    const now = Date.now();
    const t = (now - this.startTime) / 1000;

    // Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, '#0f172a');
    bgGrad.addColorStop(1, '#1e293b');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle background grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 24) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 24) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Avatar center coordinates & procedural breathing
    const cx = w / 2;
    const cy = h / 2 + 10;
    const breathY = Math.sin(t * 2) * 2;
    const scale = Math.min(w, h) / 280;

    ctx.save();
    ctx.translate(cx, cy + breathY);
    ctx.scale(scale, scale);

    // Draw stylized Upper Torso / Avatar
    this.drawAvatarBody(ctx, t);

    ctx.restore();

    // Overlay active sign badge if any
    if (this.currentGloss) {
      this.drawGlossHUD(ctx, w, h);
    }
  }

  drawAvatarBody(ctx, t) {
    // Shoulders & Chest
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;

    // Torso silhouette
    ctx.beginPath();
    ctx.moveTo(-50, 40);
    ctx.lineTo(50, 40);
    ctx.lineTo(40, 110);
    ctx.lineTo(-40, 110);
    ctx.closePath();
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.stroke();

    // Collar / Neck
    ctx.beginPath();
    ctx.moveTo(-16, 20);
    ctx.lineTo(16, 20);
    ctx.lineTo(12, 40);
    ctx.lineTo(-12, 40);
    ctx.closePath();
    ctx.fillStyle = '#f8fafc';
    ctx.fill();

    // Head
    ctx.beginPath();
    ctx.ellipse(0, -25, 32, 40, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#f1f5f9';
    ctx.fill();
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Stylized Face Visor / Features
    ctx.beginPath();
    ctx.roundRect(-22, -32, 44, 20, 8);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Visor glow eyes/expression
    ctx.fillStyle = '#38bdf8';
    ctx.shadowColor = '#06b6d4';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(-10, -22, 3, 0, Math.PI * 2);
    ctx.arc(10, -22, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0; // Reset shadow

    // Procedural hand motion based on current state
    const handWaveL = Math.sin(t * 3.5) * 12;
    const handWaveR = Math.cos(t * 3.5) * 12;

    // Left Arm & Hand
    this.drawLimb(ctx, -50, 40, -70, 75 + handWaveL, -50, 40 + handWaveL * 1.2, '#10b981');

    // Right Arm & Hand
    this.drawLimb(ctx, 50, 40, 70, 75 + handWaveR, 50, 40 + handWaveR * 1.2, '#06b6d4');
  }

  drawLimb(ctx, x1, y1, x2, y2, hx, hy, accentColor) {
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Arm bone
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(hx, hy);
    ctx.stroke();

    // Hand articulation
    ctx.fillStyle = accentColor;
    ctx.shadowColor = accentColor;
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.arc(hx, hy, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  drawGlossHUD(ctx, w, h) {
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
    ctx.lineWidth = 1;
    
    const badgeW = Math.min(220, w - 24);
    const badgeH = 34;
    const bx = (w - badgeW) / 2;
    const by = h - 46;

    ctx.beginPath();
    ctx.roundRect(bx, by, badgeW, badgeH, 17);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.font = '600 13px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`SIGN: ${this.currentGloss}`, w / 2, by + badgeH / 2);
  }
}
