/**
 * SignX - Avatar State Machine Definitions
 */

export const AVATAR_STATE = {
  IDLE: 'IDLE',
  PLAYING: 'PLAYING',
  PAUSED: 'PAUSED',
  STOPPED: 'STOPPED',
  TRANSITIONING: 'TRANSITIONING',
  SIGN_UNAVAILABLE: 'SIGN_UNAVAILABLE'
};

export const AVATAR_EVENTS = {
  STATE_CHANGE: 'stateChange',
  SIGN_START: 'signStart',
  SIGN_PROGRESS: 'signProgress',
  SIGN_END: 'signEnd',
  SEQUENCE_START: 'sequenceStart',
  SEQUENCE_COMPLETE: 'sequenceComplete',
  SIGN_NOT_FOUND: 'signNotFound',
  SPEED_CHANGE: 'speedChange'
};
