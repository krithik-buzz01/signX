/**
 * SignX - Caption Synchronization Module (Phase 5)
 * Lives in the extension page context (sidepanel / background) — NOT in the content script.
 *
 * Responsibilities:
 * - Receive caption sign sequences from youtube-caption.js via chrome.runtime messages
 * - Maintain a sign playback queue
 * - Gate: never re-sign an identical sequence
 * - Forward sign sequence to the AvatarController for playback
 * - Handle pause, resume, stop, and seek events from YouTube player
 * - Respect enable/disable toggle
 */

import { logger } from '../utils/logger.js';

export class CaptionSync {
  /**
   * @param {import('./avatar-controller.js').AvatarController} avatarController
   */
  constructor(avatarController) {
    this.controller = avatarController;
    this.enabled = true;
    this.isPaused = false;

    this.lastSignatureKey = '';     // Fingerprint of last played sequence
    this.pendingSequence = null;    // Queue of sign keys waiting to play
    this.playbackTimer = null;
    this.overlayStatusCallback = null; // Optional UI status update callback

    this._boundListener = this._onRuntimeMessage.bind(this);
    chrome.runtime.onMessage.addListener(this._boundListener);

    logger.info('[CaptionSync] Initialized.');
  }

  /* ──────────────────────────────────────────────
     PUBLIC API
  ────────────────────────────────────────────── */

  /**
   * Enable or disable caption-driven signing
   */
  setEnabled(val) {
    this.enabled = Boolean(val);
    if (!this.enabled) {
      this.stopPlayback();
    }
    logger.info(`[CaptionSync] ${this.enabled ? 'Enabled' : 'Disabled'}.`);
  }

  /**
   * Pause playback (e.g. YouTube player paused)
   */
  pause() {
    if (this.isPaused) return;
    this.isPaused = true;
    this.controller.pause();
    logger.info('[CaptionSync] Paused.');
    this._updateStatus('paused');
  }

  /**
   * Resume playback
   */
  resume() {
    if (!this.isPaused) return;
    this.isPaused = false;
    this.controller.resume();
    logger.info('[CaptionSync] Resumed.');
    this._updateStatus('playing');
  }

  /**
   * Stop all playback and reset state
   */
  stopPlayback() {
    this.pendingSequence = null;
    this.lastSignatureKey = '';
    clearTimeout(this.playbackTimer);
    this.controller.stop();
    this._updateStatus('idle');
    logger.info('[CaptionSync] Stopped.');
  }

  /**
   * Reset duplicate-prevention on seek
   */
  resetOnSeek() {
    this.lastSignatureKey = '';
    this.pendingSequence = null;
    logger.info('[CaptionSync] Seek detected — fingerprint reset.');
  }

  /**
   * Register a callback to receive status updates for UI
   * @param {Function} cb - called with { status, signSequence, unavailableWords }
   */
  onStatusUpdate(cb) {
    this.overlayStatusCallback = cb;
  }

  /**
   * Destroy: remove runtime message listener
   */
  destroy() {
    chrome.runtime.onMessage.removeListener(this._boundListener);
    this.stopPlayback();
  }

  /* ──────────────────────────────────────────────
     SIGN SEQUENCE INGESTION
  ────────────────────────────────────────────── */

  /**
   * Process an incoming sign sequence from the caption detector.
   * Enforces: duplicate prevention, pause guard, enable guard.
   *
   * @param {string[]} signKeys - e.g. ['NAMASTE', 'HOW', 'ARE', 'YOU']
   * @param {string[]} unavailableWords - words skipped due to no ISL sign
   */
  async ingestSequence(signKeys, unavailableWords = []) {
    if (!this.enabled) return;
    if (!signKeys || signKeys.length === 0) return;

    // Fingerprint for duplicate gating
    const fingerprint = signKeys.join('|');
    if (fingerprint === this.lastSignatureKey) {
      logger.info('[CaptionSync] Duplicate sequence — skipped:', fingerprint);
      return;
    }

    this.lastSignatureKey = fingerprint;

    logger.info('[CaptionSync] Ingesting sign sequence:', signKeys);
    if (unavailableWords.length > 0) {
      logger.info('[CaptionSync] Unavailable words (skipped):', unavailableWords);
    }

    this._updateStatus('playing', signKeys, unavailableWords);

    // If currently paused, queue for later
    if (this.isPaused) {
      this.pendingSequence = { signKeys, unavailableWords };
      logger.info('[CaptionSync] Queued — avatar paused.');
      return;
    }

    await this._playSequence(signKeys);
  }

  async _playSequence(signKeys) {
    try {
      await this.controller.playSequence(signKeys);
    } catch (err) {
      logger.error('[CaptionSync] Playback error:', err.message);
    }
  }

  /* ──────────────────────────────────────────────
     CHROME RUNTIME MESSAGE HANDLER
  ────────────────────────────────────────────── */

  _onRuntimeMessage(message) {
    switch (message.type) {
      case 'SIGNX_YOUTUBE_CAPTION_UPDATE': {
        const { signSequence, unavailableWords } = message.payload || {};
        if (Array.isArray(signSequence)) {
          this.ingestSequence(signSequence, unavailableWords || []);
        }
        break;
      }
      case 'SIGNX_YT_PLAYER_PAUSED':
        this.pause();
        break;
      case 'SIGNX_YT_PLAYER_RESUMED':
        this.resume();
        // If we had queued something, play it now
        if (this.pendingSequence) {
          const { signKeys } = this.pendingSequence;
          this.pendingSequence = null;
          this._playSequence(signKeys);
        }
        break;
      case 'SIGNX_YT_AVATAR_STOP':
        this.stopPlayback();
        break;
      case 'SIGNX_YT_AVATAR_SEEK':
        this.resetOnSeek();
        break;
      default:
        break;
    }
  }

  /* ──────────────────────────────────────────────
     INTERNAL
  ────────────────────────────────────────────── */

  _updateStatus(status, signSequence = [], unavailableWords = []) {
    if (this.overlayStatusCallback) {
      this.overlayStatusCallback({ status, signSequence, unavailableWords });
    }
  }
}
