/**
 * SignX - ISL Vocabulary Registry & Fallback Resolver
 * Every sign is connected to a verified ISL clip.
 * Unsupported signs explicitly return "Sign not available" without inventing fake gestures.
 */

import { ISL_CLIPS } from '../animations/isl-clips.js';

class ISLVocabulary {
  constructor() {
    this.vocabMap = new Map();
    this.initRegistry();
  }

  initRegistry() {
    // Map core signs and synonyms
    const definitions = [
      { id: 'NAMASTE', synonyms: ['namaste', 'hello', 'hi', 'greetings', 'hey', 'namaskar', 'pranam', 'hello friend'] },
      { id: 'THANK_YOU', synonyms: ['thank you', 'thanks', 'dhanyavaad', 'shukriya', 'thank-you', 'thank', 'thank you very much', 'thank you so much', 'thanks a lot', 'grateful'] },
      { id: 'WELCOME', synonyms: ['welcome', 'you are welcome', 'pleasure', 'nice to meet you'] },
      { id: 'PLEASE', synonyms: ['please', 'kripya', 'kindly'] },
      { id: 'YES', synonyms: ['yes', 'ha', 'correct', 'agree', 'yep', 'yeah', 'sure'] },
      { id: 'NO', synonyms: ['no', 'nahi', 'incorrect', 'disagree', 'nope', 'never'] },
      { id: 'HELP', synonyms: ['help', 'assist', 'assistance', 'support', 'madad', 'help me', 'can you help me'] },
      { id: 'WHERE', synonyms: ['where', 'kahan', 'where?', 'where is', 'where are'] },
      { id: 'WHAT', synonyms: ['what', 'kya', 'what?', 'what is'] },
      { id: 'WHO', synonyms: ['who', 'kaun', 'who?', 'who is'] },
      { id: 'HOW', synonyms: ['how', 'kaise', 'how?', 'how are you', 'how are you today'] },
      { id: 'ARE', synonyms: ['are', 'is', 'am', 'be'] },
      { id: 'YOU', synonyms: ['you', 'your', 'yours', 'u'] },
      { id: 'ME', synonyms: ['me', 'i', 'my', 'mine', 'myself', 'mera'] },
      { id: 'I', synonyms: ['i', 'me'] },
      { id: 'NICE', synonyms: ['nice', 'good', 'pleasant', 'great', 'fine'] },
      { id: 'MEET', synonyms: ['meet', 'meeting', 'met', 'meet you'] },
      { id: 'LOVE', synonyms: ['love', 'like', 'affection', 'pyar'] },
      { id: 'FRIEND', synonyms: ['friend', 'dost', 'companion', 'buddy', 'pal'] },
      { id: 'GOOD_MORNING', synonyms: ['good morning', 'good-morning', 'morning', 'subah'] },
      { id: 'WATER', synonyms: ['water', 'pani', 'jal', 'drink water', 'drink'] },
      { id: 'FOOD', synonyms: ['food', 'eat', 'eating', 'khana', 'meal', 'lunch', 'dinner'] },
      { id: 'DOCTOR', synonyms: ['doctor', 'physician', 'hospital', 'daktar', 'medic'] },
      { id: 'EMERGENCY', synonyms: ['emergency', 'urgent', 'danger', 'khatra', 'emergency assistance'] },
      { id: 'TRAIN_STATION', synonyms: ['train station', 'railway', 'station', 'train-station', 'train'] },
      { id: 'SCHOOL', synonyms: ['school', 'college', 'study', 'class', 'student'] },
      { id: 'MY_NAME', synonyms: ['my name is', 'my name', 'my-name', 'mera naam', 'name'] },
      { id: 'GOODBYE', synonyms: ['goodbye', 'bye', 'see you', 'tata', 'farewell'] },
      { id: 'GIVE', synonyms: ['give', 'giving', 'gave', 'offer', 'dena'] },
      { id: 'NEED', synonyms: ['need', 'require', 'needed', 'zaroorat'] },
      { id: 'WANT', synonyms: ['want', 'desire', 'wish', 'chahiye'] },
      { id: 'EVERYONE', synonyms: ['everyone', 'everybody', 'all people', 'sab log'] },
      { id: 'COME', synonyms: ['come', 'coming', 'came', 'aao'] },
      { id: 'HAPPY', synonyms: ['happy', 'glad', 'joyful', 'khush'] },
      { id: 'SAD', synonyms: ['sad', 'unhappy', 'upset', 'dukhi'] },
      { id: 'SORRY', synonyms: ['sorry', 'apologize', 'apology', 'maafi'] },
      { id: 'FAMILY', synonyms: ['family', 'parivaar', 'relatives'] },
      { id: 'HOME', synonyms: ['home', 'house', 'ghar'] },
      { id: 'WORK', synonyms: ['work', 'job', 'kaam', 'working'] },
      { id: 'KNOW', synonyms: ['know', 'knowing', 'knew', 'jaanta'] },
      { id: 'UNDERSTAND', synonyms: ['understand', 'understood', 'samajh'] },
      { id: 'LEARN', synonyms: ['learn', 'learning', 'padhai', 'seekhna'] },
      { id: 'TEACH', synonyms: ['teach', 'teacher', 'teaching', 'sikhana'] },
      { id: 'GO', synonyms: ['go', 'going', 'went', 'jaana'] }
    ];

    definitions.forEach(def => {
      this.vocabMap.set(def.id.toLowerCase(), def.id);
      def.synonyms.forEach(syn => {
        this.vocabMap.set(syn.toLowerCase().trim(), def.id);
      });
    });

    // Also register alphabet fingerspelling tokens: 'A' -> 'ISL_A'
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(char => {
      this.vocabMap.set(char.toLowerCase(), `ISL_${char}`);
      this.vocabMap.set(`isl_${char.toLowerCase()}`, `ISL_${char}`);
    });

    // Register numeric digits: '1' -> 'ISL_1'
    ['1', '2', '3'].forEach(num => {
      this.vocabMap.set(num, `ISL_${num}`);
      this.vocabMap.set(`isl_${num}`, `ISL_${num}`);
    });
  }

  /**
   * Resolve a word or phrase to a verified clip
   * @param {string} token 
   * @returns {{ found: boolean, clipId?: string, clip?: object, isFingerspelled?: boolean, error?: string }}
   */
  resolve(token) {
    if (!token || typeof token !== 'string') {
      return { found: false, error: 'Empty token' };
    }

    const clean = token.toLowerCase().trim().replace(/[.,!?;:]/g, '');
    
    // 1. Direct vocabulary lookup
    if (this.vocabMap.has(clean)) {
      const clipId = this.vocabMap.get(clean);
      if (ISL_CLIPS.has(clipId)) {
        return {
          found: true,
          clipId,
          clip: ISL_CLIPS.get(clipId),
          isFingerspelled: clipId.startsWith('ISL_') && clipId.length === 5
        };
      }
    }

    // 2. Direct upper clip ID lookup
    const upperId = token.toUpperCase().trim().replace(/[-]/g, '_');
    if (ISL_CLIPS.has(upperId)) {
      return {
        found: true,
        clipId: upperId,
        clip: ISL_CLIPS.get(upperId)
      };
    }

    // 3. Fallback: Not available in verified dictionary
    // We strictly return found: false without inventing arbitrary gestures
    return {
      found: false,
      clipId: null,
      word: token,
      error: 'Sign not available'
    };
  }

  /**
   * Resolve a full sequence of tokens
   */
  resolveSequence(tokens) {
    return tokens.map(token => ({
      token,
      ...this.resolve(token)
    }));
  }

  getAllSupportedSigns() {
    return Array.from(ISL_CLIPS.keys()).map(id => ({
      id,
      name: ISL_CLIPS.get(id).name,
      durationMs: ISL_CLIPS.get(id).durationMs
    }));
  }
}

export const islVocabulary = new ISLVocabulary();
