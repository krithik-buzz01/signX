/**
 * SignX - 3D Upper-Body Humanoid Avatar Player
 * High-visibility accessibility avatar with fully articulated 5-finger hands,
 * smooth 60fps keyframe interpolation, friendly human-like appearance, and neutral studio environment.
 */

import { BASE_POSES } from './gestures/base-poses.js';
import { ISL_HANDSHAPES } from './gestures/handshapes.js';
import { AnimationClip } from './animations/animation-clip.js';

export class AvatarPlayer {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement ? canvasElement.getContext('2d') : null;
    this.currentPose = { ...BASE_POSES.NEUTRAL_REST };
    this.currentClip = null;
    this.clipProgress = 0; // 0 to 1
    this.playbackSpeed = 1.0;
    this.isRunning = false;
    this.animFrameId = null;
    this.lastFrameTime = performance.now();
    
    // Fallback indicator state
    this.unavailableSign = null; // String if active fallback
    this.activeSignLabel = 'READY';

    // Stylized theme colors
    this.colors = {
      bgGradTop: '#0b1120',
      bgGradBottom: '#1e293b',
      skin: '#fbd4b7',
      skinShadow: '#dfa685',
      clothing: '#1e3a8a', // Deep royal accessible blue
      clothingAccent: '#06b6d4',
      hair: '#1f2937',
      eyes: '#0284c7',
      joints: '#38bdf8',
      handOutline: '#ffffff'
    };
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastFrameTime = performance.now();
    this.loop();
  }

  stop() {
    this.isRunning = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }

  setClip(clip, signLabel = null) {
    this.currentClip = clip;
    this.clipProgress = 0;
    this.unavailableSign = null;
    this.activeSignLabel = signLabel || clip?.name || 'IDLE';
  }

  setUnavailableSign(word) {
    this.unavailableSign = word;
    this.activeSignLabel = 'SIGN NOT AVAILABLE';
    this.currentClip = null;
  }

  setSpeed(speed) {
    this.playbackSpeed = Math.max(0.25, Math.min(3.0, speed));
  }

  loop() {
    if (!this.isRunning) return;

    const now = performance.now();
    const deltaMs = now - this.lastFrameTime;
    this.lastFrameTime = now;

    this.update(deltaMs);
    this.render();

    this.animFrameId = requestAnimationFrame(() => this.loop());
  }

  update(deltaMs) {
    if (this.currentClip) {
      const effectiveDuration = this.currentClip.durationMs / this.playbackSpeed;
      this.clipProgress += deltaMs / effectiveDuration;

      if (this.clipProgress >= 1.0) {
        this.clipProgress = 1.0;
        this.currentPose = this.currentClip.sample(1.0);
        if (this.onClipEnd) {
          const finished = this.currentClip;
          this.currentClip = null;
          this.onClipEnd(finished);
        }
      } else {
        this.currentPose = this.currentClip.sample(this.clipProgress);
      }
    } else {
      // Idle procedural breathing
      const t = performance.now() / 1000;
      const breath = Math.sin(t * 2) * 0.015;
      this.currentPose.torso.y = breath;
    }
  }

  render() {
    if (!this.ctx || !this.canvas) return;

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    // 1. Studio Lighting Background
    const bgGrad = ctx.createRadialGradient(w / 2, h / 2 - 20, 20, w / 2, h / 2, Math.max(w, h));
    bgGrad.addColorStop(0, '#172554'); // Subtle deep blue backlight
    bgGrad.addColorStop(0.6, '#0f172a');
    bgGrad.addColorStop(1, '#020617');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle alignment grid for signing space
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    // 2. Camera Viewport Matrix (Centered Upper Body)
    ctx.save();
    const centerX = w / 2;
    const centerY = h * 0.52;
    const unitScale = Math.min(w, h) * 1.05;

    ctx.translate(centerX + (this.currentPose.torso.x || 0) * unitScale, centerY + (this.currentPose.torso.y || 0) * unitScale);

    // 3. Draw Anatomical 3D Body in proper depth layers
    this.drawTorso(ctx, unitScale);
    this.drawHead(ctx, unitScale);
    this.drawArmsAndHands(ctx, unitScale);

    ctx.restore();

    // 4. Draw HUD / Sign Label / Fallback Banner
    this.drawSignHUD(ctx, w, h);
  }

  drawHead(ctx, s) {
    const head = this.currentPose.head || { pitch: 0, yaw: 0, roll: 0 };
    const hx = (head.yaw || 0) * 15;
    const hy = -s * 0.32 + (head.pitch || 0) * 20;

    ctx.save();
    ctx.translate(hx, hy);
    ctx.rotate(head.roll || 0);

    // Neck
    ctx.fillStyle = this.colors.skinShadow;
    ctx.beginPath();
    ctx.roundRect(-s * 0.045, s * 0.06, s * 0.09, s * 0.08, 4);
    ctx.fill();

    // Head Base & Jaw
    ctx.fillStyle = this.colors.skin;
    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(0, 0, s * 0.10, s * 0.125, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Modern Hair
    ctx.fillStyle = this.colors.hair;
    ctx.beginPath();
    ctx.ellipse(0, -s * 0.065, s * 0.105, s * 0.08, 0, Math.PI, Math.PI * 2);
    ctx.fill();

    // Friendly Expressive Face: Eyes
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(-s * 0.038, -s * 0.015, s * 0.018, s * 0.014, 0, 0, Math.PI * 2);
    ctx.ellipse(s * 0.038, -s * 0.015, s * 0.018, s * 0.014, 0, 0, Math.PI * 2);
    ctx.fill();

    // Irises
    ctx.fillStyle = this.colors.eyes;
    ctx.beginPath();
    ctx.arc(-s * 0.038, -s * 0.015, s * 0.009, 0, Math.PI * 2);
    ctx.arc(s * 0.038, -s * 0.015, s * 0.009, 0, Math.PI * 2);
    ctx.fill();

    // Friendly Smile
    ctx.strokeStyle = this.colors.skinShadow;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(0, s * 0.035, s * 0.025, 0.2, Math.PI - 0.2);
    ctx.stroke();

    ctx.restore();
  }

  drawTorso(ctx, s) {
    const lean = this.currentPose.torso.lean || 0;

    ctx.save();
    ctx.rotate(lean * 0.2);

    // Shoulders and Chest Vest
    ctx.fillStyle = this.colors.clothing;
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.moveTo(-s * 0.32, -s * 0.18); // Left shoulder
    ctx.quadraticCurveTo(0, -s * 0.16, s * 0.32, -s * 0.18); // Right shoulder
    ctx.lineTo(s * 0.22, s * 0.32); // Right waist
    ctx.lineTo(-s * 0.22, s * 0.32); // Left waist
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // V-Neck / Collar Accent
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(-s * 0.06, -s * 0.17);
    ctx.lineTo(0, -s * 0.06);
    ctx.lineTo(s * 0.06, -s * 0.17);
    ctx.closePath();
    ctx.fill();

    // SignX Brand Chest Badge
    ctx.fillStyle = this.colors.clothingAccent;
    ctx.beginPath();
    ctx.arc(-s * 0.12, -s * 0.06, s * 0.016, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  drawArmsAndHands(ctx, s) {
    const leftArm = this.currentPose.leftArm;
    const rightArm = this.currentPose.rightArm;

    // Draw Left Arm (Mirror perspective)
    this.drawLimb(ctx, leftArm, this.currentPose.leftHand, -1, s);

    // Draw Right Arm
    this.drawLimb(ctx, rightArm, this.currentPose.rightHand, 1, s);
  }

  drawLimb(ctx, armData, handshape, sideMultiplier, s) {
    if (!armData) return;

    const shoulderX = armData.shoulderX * s;
    const shoulderY = -armData.shoulderY * s;
    const elbowX = armData.elbowX * s;
    const elbowY = -armData.elbowY * s;
    const wristX = armData.wristX * s;
    const wristY = -armData.wristY * s;

    // Upper Arm
    ctx.strokeStyle = this.colors.clothing;
    ctx.lineWidth = s * 0.085;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(shoulderX, shoulderY);
    ctx.lineTo(elbowX, elbowY);
    ctx.stroke();

    // Forearm
    ctx.strokeStyle = this.colors.skin;
    ctx.lineWidth = s * 0.065;
    ctx.beginPath();
    ctx.moveTo(elbowX, elbowY);
    ctx.lineTo(wristX, wristY);
    ctx.stroke();

    // Joint caps
    ctx.fillStyle = this.colors.skinShadow;
    ctx.beginPath();
    ctx.arc(elbowX, elbowY, s * 0.038, 0, Math.PI * 2);
    ctx.fill();

    // Draw High-Visibility Articulated 5-Finger Hand
    this.drawArticulatedHand(ctx, wristX, wristY, armData.rotation || 0, handshape, sideMultiplier, s);
  }

  drawArticulatedHand(ctx, wx, wy, rotation, handshapeObj, side, s) {
    const hs = typeof handshapeObj === 'string' 
      ? (ISL_HANDSHAPES[handshapeObj] || ISL_HANDSHAPES.OPEN_FLAT)
      : (handshapeObj || ISL_HANDSHAPES.OPEN_FLAT);

    ctx.save();
    ctx.translate(wx, wy);
    ctx.rotate(rotation + (side === -1 ? Math.PI : 0));

    const palmW = s * 0.062;
    const palmH = s * 0.070;

    // Palm Shadow & Base
    ctx.fillStyle = this.colors.skin;
    ctx.strokeStyle = this.colors.handOutline;
    ctx.lineWidth = 2.5;

    ctx.beginPath();
    ctx.roundRect(-palmW / 2, -palmH / 2, palmW, palmH, s * 0.016);
    ctx.fill();
    ctx.stroke();

    // 5 Articulated Fingers: [Thumb, Index, Middle, Ring, Pinky]
    const fingerBases = [
      { name: 'Thumb', x: -palmW * 0.42, y: palmH * 0.15, len: s * 0.050, angle: -0.65 },
      { name: 'Index', x: -palmW * 0.30, y: -palmH * 0.45, len: s * 0.065, angle: -0.10 },
      { name: 'Middle', x: -palmW * 0.02, y: -palmH * 0.48, len: s * 0.072, angle: 0.00 },
      { name: 'Ring', x: palmW * 0.25, y: -palmH * 0.45, len: s * 0.064, angle: 0.10 },
      { name: 'Pinky', x: palmW * 0.42, y: -palmH * 0.35, len: s * 0.052, angle: 0.25 }
    ];

    const flexions = hs.flexion || [0, 0, 0, 0, 0];
    const spreads = hs.spread || [0, 0, 0, 0, 0];

    fingerBases.forEach((f, i) => {
      const flexion = flexions[i] ?? 0;
      const spread = spreads[i] ?? 0;
      const curLen = f.len * (1 - flexion * 0.65); // Shortens visually when curled toward camera
      const fAngle = f.angle + spread * 0.35;

      const fx2 = f.x + Math.sin(fAngle) * curLen;
      const fy2 = f.y - Math.cos(fAngle) * curLen;

      // Finger Phalanx
      ctx.strokeStyle = flexion > 0.6 ? this.colors.skinShadow : this.colors.skin;
      ctx.lineWidth = s * 0.022;
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(f.x, f.y);
      ctx.lineTo(fx2, fy2);
      ctx.stroke();

      // Fingertip Node
      ctx.fillStyle = flexion > 0.7 ? this.colors.skinShadow : '#fff';
      ctx.beginPath();
      ctx.arc(fx2, fy2, s * 0.010, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.restore();
  }

  drawSignHUD(ctx, w, h) {
    const badgeW = Math.min(260, w - 24);
    const badgeH = 36;
    const bx = (w - badgeW) / 2;
    const by = h - 48;

    if (this.unavailableSign) {
      // Fallback State Banner
      ctx.fillStyle = 'rgba(239, 68, 68, 0.9)';
      ctx.strokeStyle = '#fca5a5';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(bx, by, badgeW, badgeH, 18);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 12px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Sign not available: "${this.unavailableSign}"`, w / 2, by + badgeH / 2);
      return;
    }

    // Normal Active Sign Badge
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(bx, by, badgeW, badgeH, 18);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.font = '700 13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`ISL SIGN: ${this.activeSignLabel}`, w / 2, by + badgeH / 2);
  }
}
