/**
 * SignX - ECHO 3D Humanoid Avatar Engine (WebGL / Three.js)
 * High-fidelity 3D Humanoid ASL/ISL Avatar Rig v2.4 with articulated arms,
 * 5-finger hands, expressive face, hair, and real-time signing & fingerspelling.
 */

export class HumanoidAvatar3D {
  constructor(containerElement, options = {}) {
    this.container = containerElement;
    this.options = options;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.rig = {};
    this.animationQueue = [];
    this.currentAnimation = null;
    this.animTime = 0;
    this.speed = options.speed || 1.0;
    this.isPaused = false;
    this.emotion = 'friendly'; // friendly, happy, neutral, focused
    this.onSignChange = options.onSignChange || null;
    this.onComplete = options.onComplete || null;

    this.isOrbiting = false;
    this.prevMouse = { x: 0, y: 0 };
    this.cameraRotation = { x: 0.05, y: 0 };

    this.init();
  }

  init() {
    if (!this.container) return;
    const THREE = window.THREE;
    if (!THREE) {
      console.error('Three.js is not loaded.');
      return;
    }

    const width = this.container.clientWidth || 480;
    const height = this.container.clientHeight || 520;

    // 1. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x130e24); // Dark studio purple

    this.camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    this.camera.position.set(0, 0.35, 2.6);

    // 2. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Clear previous children
    while (this.container.firstChild) {
      this.container.removeChild(this.container.firstChild);
    }
    this.container.appendChild(this.renderer.domElement);

    // 3. Studio Lighting
    this.setupLighting(THREE);

    // 4. Build 3D Humanoid Rig (Head, Hair, Eyes, Mouth, Torso, Arms, 5-Finger Hands)
    this.buildHumanoidRig(THREE);

    // 5. Mouse Interaction for 3D Camera Orbit
    this.setupOrbitControls();

    // 6. Responsive Resize
    window.addEventListener('resize', () => this.onResize());

    // 7. Start Render Loop
    this.clock = new THREE.Clock();
    this.animate();
  }

  setupLighting(THREE) {
    // Ambient light
    const ambient = new THREE.AmbientLight(0xd8b4fe, 0.65);
    this.scene.add(ambient);

    // Key Light (Warm Glow)
    const keyLight = new THREE.DirectionalLight(0xffedd5, 1.1);
    keyLight.position.set(2, 3, 3);
    keyLight.castShadow = true;
    this.scene.add(keyLight);

    // Fill Light (Cool Cyan/Purple)
    const fillLight = new THREE.DirectionalLight(0xa78bfa, 0.7);
    fillLight.position.set(-2.5, 1.5, 2);
    this.scene.add(fillLight);

    // Back / Rim Light (Crisp Halo)
    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    rimLight.position.set(0, 3, -3);
    this.scene.add(rimLight);
  }

  buildHumanoidRig(THREE) {
    const root = new THREE.Group();
    root.position.set(0, -0.45, 0);
    this.scene.add(root);
    this.rig.root = root;

    // Materials
    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xdeb887, // Warm rich skin
      roughness: 0.55,
      metalness: 0.05
    });

    const hairMat = new THREE.MeshStandardMaterial({
      color: 0x4a2511, // Stylized dark brown sculpted hair
      roughness: 0.6,
      metalness: 0.1
    });

    const shirtMat = new THREE.MeshStandardMaterial({
      color: 0xdbeafe, // Modern sky-tinted white t-shirt
      roughness: 0.7,
      metalness: 0.02
    });

    const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const irisMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const browMat = new THREE.MeshStandardMaterial({ color: 0x2e180d, roughness: 0.8 });
    const mouthMat = new THREE.MeshBasicMaterial({ color: 0x881337 });

    // --- TORSO ---
    const torsoGroup = new THREE.Group();
    const torsoGeo = new THREE.CylinderGeometry(0.32, 0.28, 0.68, 32);
    const torsoMesh = new THREE.Mesh(torsoGeo, shirtMat);
    torsoMesh.position.y = 0.34;
    torsoGroup.add(torsoMesh);

    // Collar / Neckline ring
    const collarGeo = new THREE.TorusGeometry(0.16, 0.025, 16, 32);
    const collarMesh = new THREE.Mesh(collarGeo, shirtMat);
    collarMesh.rotation.x = Math.PI / 2;
    collarMesh.position.set(0, 0.68, 0);
    torsoGroup.add(collarMesh);

    root.add(torsoGroup);
    this.rig.torso = torsoGroup;

    // --- NECK & HEAD GROUP ---
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.75, 0);

    // Neck
    const neckGeo = new THREE.CylinderGeometry(0.11, 0.13, 0.16, 24);
    const neckMesh = new THREE.Mesh(neckGeo, skinMat);
    neckMesh.position.y = 0.06;
    headGroup.add(neckMesh);

    // Head Sphere
    const headGeo = new THREE.SphereGeometry(0.30, 32, 32);
    const headMesh = new THREE.Mesh(headGeo, skinMat);
    headMesh.position.set(0, 0.32, 0);
    headGroup.add(headMesh);

    // 3D Sculpted Hair (Top volume + fringe swoop)
    const hairGroup = new THREE.Group();
    
    // Hair base cap
    const hairCapGeo = new THREE.SphereGeometry(0.315, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const hairCap = new THREE.Mesh(hairCapGeo, hairMat);
    hairCap.position.set(0, 0.34, -0.01);
    hairGroup.add(hairCap);

    // Hair Top Volume Puff (as shown in screenshot)
    const hairPuffGeo = new THREE.SphereGeometry(0.20, 24, 24);
    const hairPuff = new THREE.Mesh(hairPuffGeo, hairMat);
    hairPuff.scale.set(1.1, 0.8, 1.2);
    hairPuff.position.set(0.04, 0.54, 0.05);
    hairPuff.rotation.z = -0.15;
    hairGroup.add(hairPuff);

    // Hair Side Swoop
    const swoopGeo = new THREE.SphereGeometry(0.14, 16, 16);
    const swoop = new THREE.Mesh(swoopGeo, hairMat);
    swoop.scale.set(1.3, 0.6, 0.8);
    swoop.position.set(-0.12, 0.48, 0.18);
    swoop.rotation.set(0.2, 0.4, 0.3);
    hairGroup.add(swoop);

    headGroup.add(hairGroup);

    // --- EYES ---
    const createEye = (isLeft) => {
      const eyeG = new THREE.Group();
      const sclera = new THREE.Mesh(new THREE.SphereGeometry(0.055, 16, 16), eyeWhiteMat);
      sclera.scale.set(1, 1.1, 0.5);
      eyeG.add(sclera);

      const iris = new THREE.Mesh(new THREE.CircleGeometry(0.032, 16), irisMat);
      iris.position.set(0, 0, 0.028);
      eyeG.add(iris);

      const pupil = new THREE.Mesh(new THREE.CircleGeometry(0.020, 16), pupilMat);
      pupil.position.set(0, 0, 0.030);
      eyeG.add(pupil);

      // Eye highlight shine
      const shine = new THREE.Mesh(new THREE.CircleGeometry(0.008, 12), eyeWhiteMat);
      shine.position.set(0.012, 0.012, 0.032);
      eyeG.add(shine);

      const xPos = isLeft ? -0.105 : 0.105;
      eyeG.position.set(xPos, 0.33, 0.26);
      return eyeG;
    };

    headGroup.add(createEye(true));
    headGroup.add(createEye(false));

    // --- EYEBROWS ---
    const createBrow = (isLeft) => {
      const brow = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.016, 0.02), browMat);
      const xPos = isLeft ? -0.105 : 0.105;
      brow.position.set(xPos, 0.41, 0.28);
      brow.rotation.z = isLeft ? 0.08 : -0.08;
      return brow;
    };
    this.rig.leftBrow = createBrow(true);
    this.rig.rightBrow = createBrow(false);
    headGroup.add(this.rig.leftBrow);
    headGroup.add(this.rig.rightBrow);

    // --- NOSE ---
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.06, 16), skinMat);
    nose.position.set(0, 0.27, 0.31);
    nose.rotation.x = -Math.PI / 8;
    headGroup.add(nose);

    // --- MOUTH ---
    const mouthGroup = new THREE.Group();
    const mouthMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.02, 16, 1, false, 0, Math.PI), mouthMat);
    mouthMesh.rotation.z = Math.PI;
    mouthMesh.rotation.x = Math.PI / 2;
    mouthGroup.position.set(0, 0.20, 0.29);
    mouthGroup.add(mouthMesh);
    headGroup.add(mouthGroup);
    this.rig.mouth = mouthGroup;

    root.add(headGroup);
    this.rig.head = headGroup;

    // --- ARMS & 5-FINGER HANDS (LEFT & RIGHT) ---
    this.rig.leftArm = this.buildArm(THREE, true, skinMat, shirtMat);
    this.rig.rightArm = this.buildArm(THREE, false, skinMat, shirtMat);
    root.add(this.rig.leftArm.shoulderGroup);
    root.add(this.rig.rightArm.shoulderGroup);

    // Rest pose
    this.setRestPose();
  }

  buildArm(THREE, isLeft, skinMat, shirtMat) {
    const sign = isLeft ? -1 : 1;
    const shoulderGroup = new THREE.Group();
    shoulderGroup.position.set(sign * 0.36, 0.62, 0);

    // Shoulder cap (shirt sleeve)
    const sleeveGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const sleeve = new THREE.Mesh(sleeveGeo, shirtMat);
    shoulderGroup.add(sleeve);

    // Upper Arm
    const upperArm = new THREE.Group();
    const bicepGeo = new THREE.CylinderGeometry(0.065, 0.055, 0.28, 16);
    const bicep = new THREE.Mesh(bicepGeo, skinMat);
    bicep.position.y = -0.14;
    upperArm.add(bicep);
    shoulderGroup.add(upperArm);

    // Forearm / Elbow
    const forearm = new THREE.Group();
    forearm.position.set(0, -0.28, 0);
    const forearmGeo = new THREE.CylinderGeometry(0.055, 0.045, 0.26, 16);
    const forearmMesh = new THREE.Mesh(forearmGeo, skinMat);
    forearmMesh.position.y = -0.13;
    forearm.add(forearmMesh);
    upperArm.add(forearm);

    // Hand & Wrist
    const handGroup = new THREE.Group();
    handGroup.position.set(0, -0.26, 0);

    // Palm
    const palmGeo = new THREE.BoxGeometry(0.09, 0.10, 0.035);
    const palmMesh = new THREE.Mesh(palmGeo, skinMat);
    palmMesh.position.y = -0.05;
    handGroup.add(palmMesh);

    // 5 Articulated Fingers
    const fingers = [];
    const fingerConfigs = [
      { name: 'thumb', x: sign * 0.05, y: -0.02, len: 0.06, thick: 0.016, rotZ: sign * 0.5 },
      { name: 'index', x: -0.03, y: -0.10, len: 0.075, thick: 0.014, rotZ: 0 },
      { name: 'middle', x: -0.01, y: -0.10, len: 0.082, thick: 0.014, rotZ: 0 },
      { name: 'ring', x: 0.015, y: -0.10, len: 0.072, thick: 0.013, rotZ: 0 },
      { name: 'pinky', x: 0.035, y: -0.09, len: 0.058, thick: 0.012, rotZ: 0 }
    ];

    fingerConfigs.forEach(cfg => {
      const fGroup = new THREE.Group();
      fGroup.position.set(cfg.x, cfg.y, 0);
      fGroup.rotation.z = cfg.rotZ;

      const fMesh = new THREE.Mesh(new THREE.CylinderGeometry(cfg.thick, cfg.thick * 0.85, cfg.len, 10), skinMat);
      fMesh.position.y = -cfg.len / 2;
      fGroup.add(fMesh);

      handGroup.add(fGroup);
      fingers.push(fGroup);
    });

    forearm.add(handGroup);

    return {
      shoulderGroup,
      upperArm,
      forearm,
      handGroup,
      fingers,
      isLeft
    };
  }

  setRestPose() {
    if (!this.rig.leftArm || !this.rig.rightArm) return;

    // Natural relaxed posture
    this.rig.leftArm.upperArm.rotation.set(0.1, 0, 0.18);
    this.rig.leftArm.forearm.rotation.set(-0.35, 0, -0.15);
    this.rig.leftArm.handGroup.rotation.set(0, 0, 0);

    this.rig.rightArm.upperArm.rotation.set(0.1, 0, -0.18);
    this.rig.rightArm.forearm.rotation.set(-0.35, 0, 0.15);
    this.rig.rightArm.handGroup.rotation.set(0, 0, 0);

    this.rig.head.rotation.set(0, 0, 0);
  }

  /* ================= REAL-TIME SIGNING & ANIMATION PIPELINE ================= */
  playSign(signName, details = {}) {
    const name = (signName || 'READY').toUpperCase();
    const category = details.category || (details.isLetter ? 'FINGERSPELLING' : 'ISL VOCABULARY');
    const subtitle = details.subtitle || details.description || (details.isLetter ? `Letter ${name}` : `Sign: ${name}`);

    this.currentAnimation = {
      name,
      category,
      subtitle,
      startTime: this.clock.getElapsedTime(),
      duration: Math.max(0.8, (details.duration || 1.6) / this.speed),
      progress: 0,
      details
    };

    if (this.onSignChange) {
      this.onSignChange({ name, category, subtitle, progress: 0 });
    }
  }

  playSequence(signArray) {
    if (!signArray || signArray.length === 0) return;
    this.animationQueue = [...signArray];
    this.playNextInQueue();
  }

  playNextInQueue() {
    if (this.animationQueue.length === 0) {
      this.currentAnimation = null;
      this.setRestPose();
      if (this.onComplete) this.onComplete();
      return;
    }

    const nextSign = this.animationQueue.shift();
    const isLetter = typeof nextSign === 'string' && nextSign.length === 1 && /[A-Z0-9]/i.test(nextSign);
    
    let subtitle = `ISL Gesture: ${nextSign}`;
    if (isLetter) {
      subtitle = this.getFingerspellingDescription(nextSign.toUpperCase());
    } else if (nextSign.toUpperCase() === 'NAMASTE' || nextSign.toUpperCase() === 'HELLO') {
      subtitle = 'Both palms pressed in front of chest in greeting';
    } else if (nextSign.toUpperCase() === 'THANK_YOU') {
      subtitle = 'Right hand moves forward from chin with palm open';
    } else if (nextSign.toUpperCase() === 'WHERE') {
      subtitle = 'Both palms open facing up, shaking gently side-to-side';
    }

    this.playSign(nextSign, { isLetter, subtitle, duration: isLetter ? 1.0 : 1.5 });
  }

  getFingerspellingDescription(letter) {
    const map = {
      'A': 'Fist with thumb resting upright beside index',
      'B': 'Four fingers upright and flat, thumb folded across palm',
      'C': 'Curved hand forming a "C" shape',
      'D': 'Index finger pointed up, other fingers touching thumb in circle',
      'E': 'All fingers curled down to touch the thumb tip',
      'F': 'Index tip and thumb touching in circle, other 3 fingers raised',
      'G': 'Index and thumb pointing parallel horizontally',
      'H': 'Index and middle fingers extended horizontally side-by-side',
      'I': 'Pinky finger extended upright, other fingers in fist',
      'L': 'Thumb and index extended at right angle forming an "L"',
      'M': 'Three fingers folded over the tucked thumb',
      'N': 'Two fingers folded over the tucked thumb in a fist',
      'O': 'All fingertips touching thumb to form an "O"',
      'P': 'Middle finger down, index forward, thumb supporting ("K" facing down)',
      'Q': 'Thumb and index pointing downwards',
      'R': 'Index and middle fingers crossed tightly',
      'S': 'Tight fist with thumb folded across the front of fingers',
      'T': 'Thumb tucked between index and middle fingers in a fist',
      'U': 'Index and middle fingers held together straight upright',
      'V': 'Index and middle fingers spread in a "V" peace sign',
      'W': 'Index, middle, and ring fingers spread upwards forming a "W"',
      'X': 'Index finger crooked into a hook shape',
      'Y': 'Thumb and pinky extended wide ("hang loose" gesture)',
      'Z': 'Index finger drawing a "Z" in the air'
    };
    return map[letter] || `Fingerspelling letter ${letter}`;
  }

  pause() {
    this.isPaused = true;
  }

  resume() {
    this.isPaused = false;
  }

  stop() {
    this.animationQueue = [];
    this.currentAnimation = null;
    this.isPaused = false;
    this.setRestPose();
    if (this.onSignChange) {
      this.onSignChange({ name: 'READY', category: 'STANDBY', subtitle: 'Avatar is ready to sign', progress: 0 });
    }
  }

  setSpeed(speed = 1.0) {
    this.speed = Math.max(0.25, Math.min(3.0, speed));
  }

  setEmotion(emotion) {
    this.emotion = emotion;
    if (emotion === 'happy') {
      this.rig.leftBrow.rotation.z = 0.20;
      this.rig.rightBrow.rotation.z = -0.20;
    } else if (emotion === 'friendly') {
      this.rig.leftBrow.rotation.z = 0.08;
      this.rig.rightBrow.rotation.z = -0.08;
    } else {
      this.rig.leftBrow.rotation.z = 0;
      this.rig.rightBrow.rotation.z = 0;
    }
  }

  setupOrbitControls() {
    const dom = this.renderer.domElement;

    dom.addEventListener('mousedown', (e) => {
      this.isOrbiting = true;
      this.prevMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isOrbiting) return;
      const dx = e.clientX - this.prevMouse.x;
      const dy = e.clientY - this.prevMouse.y;
      this.prevMouse = { x: e.clientX, y: e.clientY };

      this.cameraRotation.y += dx * 0.008;
      this.cameraRotation.x = Math.max(-0.4, Math.min(0.4, this.cameraRotation.x + dy * 0.008));
    });

    window.addEventListener('mouseup', () => {
      this.isOrbiting = false;
    });

    // Touch support for mobile
    dom.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isOrbiting = true;
        this.prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    });

    window.addEventListener('touchmove', (e) => {
      if (!this.isOrbiting || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - this.prevMouse.x;
      const dy = e.touches[0].clientY - this.prevMouse.y;
      this.prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };

      this.cameraRotation.y += dx * 0.008;
      this.cameraRotation.x = Math.max(-0.4, Math.min(0.4, this.cameraRotation.x + dy * 0.008));
    });

    window.addEventListener('touchend', () => {
      this.isOrbiting = false;
    });
  }

  onResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth || 480;
    const height = this.container.clientHeight || 520;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());

    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // 1. Idle Breathing & Micro Sway
    if (!this.isPaused) {
      const breath = Math.sin(elapsedTime * 2.2) * 0.015;
      this.rig.torso.position.y = 0.02 + breath;
      this.rig.head.position.y = 0.75 + breath * 1.2;
      this.rig.head.rotation.y = Math.sin(elapsedTime * 0.8) * 0.03;
    }

    // 2. Process Active Sign Animation
    if (this.currentAnimation && !this.isPaused) {
      const elapsed = this.clock.getElapsedTime() - this.currentAnimation.startTime;
      const progress = Math.min(1.0, elapsed / this.currentAnimation.duration);
      this.currentAnimation.progress = progress;

      this.applySignPose(this.currentAnimation.name, progress);

      if (progress >= 1.0) {
        // Step to next queued sign
        this.playNextInQueue();
      }
    }

    // 3. Camera Rotation smoothly damped
    const radius = 2.6;
    this.camera.position.x = Math.sin(this.cameraRotation.y) * radius * Math.cos(this.cameraRotation.x);
    this.camera.position.z = Math.cos(this.cameraRotation.y) * radius * Math.cos(this.cameraRotation.x);
    this.camera.position.y = 0.35 + Math.sin(this.cameraRotation.x) * radius;
    this.camera.lookAt(0, 0.30, 0);

    this.renderer.render(this.scene, this.camera);
  }

  applySignPose(signKey, progress) {
    const p = Math.sin(progress * Math.PI); // Easing curve: 0 -> 1 -> 0
    const key = signKey.toUpperCase();

    // NAMASTE / HELLO: Both palms meet in center
    if (key === 'NAMASTE' || key === 'HELLO') {
      this.rig.leftArm.upperArm.rotation.set(-0.6 * p, 0.4 * p, 0.5 * p);
      this.rig.leftArm.forearm.rotation.set(-1.4 * p, -0.6 * p, 0);
      this.rig.leftArm.handGroup.rotation.set(0, 0.8 * p, 0);

      this.rig.rightArm.upperArm.rotation.set(-0.6 * p, -0.4 * p, -0.5 * p);
      this.rig.rightArm.forearm.rotation.set(-1.4 * p, 0.6 * p, 0);
      this.rig.rightArm.handGroup.rotation.set(0, -0.8 * p, 0);

      this.rig.head.rotation.x = 0.12 * p; // Respectful nod
    }
    // THANK YOU: Right hand to chin then outward
    else if (key === 'THANK_YOU') {
      const reach = Math.sin(progress * Math.PI);
      this.rig.rightArm.upperArm.rotation.set((-0.7 - 0.2 * progress) * reach, 0.2 * reach, -0.2 * reach);
      this.rig.rightArm.forearm.rotation.set((-1.2 + 0.6 * progress) * reach, 0, 0);
      this.rig.rightArm.handGroup.rotation.set(0.3 * reach, 0, 0);
      this.rig.head.rotation.x = 0.08 * reach;
    }
    // HOW / ARE / YOU / WHERE: Open hands query gesture
    else if (key === 'HOW' || key === 'WHERE' || key === 'WHAT') {
      this.rig.leftArm.upperArm.rotation.set(-0.3 * p, 0.5 * p, 0.4 * p);
      this.rig.leftArm.forearm.rotation.set(-1.1 * p, -0.8 * p, 0);
      this.rig.leftArm.handGroup.rotation.set(-0.4 * p, 0, 0);

      this.rig.rightArm.upperArm.rotation.set(-0.3 * p, -0.5 * p, -0.4 * p);
      this.rig.rightArm.forearm.rotation.set(-1.1 * p, 0.8 * p, 0);
      this.rig.rightArm.handGroup.rotation.set(-0.4 * p, 0, 0);

      this.rig.head.rotation.y = Math.sin(progress * Math.PI * 2) * 0.08;
    }
    // PLEASE / HELP / WATER
    else if (key === 'PLEASE' || key === 'HELP') {
      this.rig.rightArm.upperArm.rotation.set(-0.5 * p, 0, -0.3 * p);
      this.rig.rightArm.forearm.rotation.set(-1.3 * p, 0.4 * p, 0);
      this.rig.rightArm.handGroup.rotation.set(0, 0.5 * p, 0);
    }
    // FINGERSPELLING: Articulated hand raised in front of shoulder
    else {
      this.rig.rightArm.upperArm.rotation.set(-0.6 * p, -0.2 * p, -0.25 * p);
      this.rig.rightArm.forearm.rotation.set(-1.45 * p, 0.4 * p, 0);
      this.rig.rightArm.handGroup.rotation.set(0.2 * p, 0.4 * p, 0);

      // Articulate fingers based on letter
      if (this.rig.rightArm.fingers) {
        this.rig.rightArm.fingers.forEach((f, idx) => {
          f.rotation.x = (idx > 1 ? 1.2 : 0.2) * p;
        });
      }
    }
  }
}
