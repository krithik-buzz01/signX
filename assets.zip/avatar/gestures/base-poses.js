/**
 * SignX - Base Anatomical Upper-Body Poses
 * Defines 3D joint coordinate offsets and rotational Euler angles (in radians)
 */

export const BASE_POSES = {
  // Neutral resting pose (Hands lowered comfortably near waist)
  NEUTRAL_REST: {
    head: { pitch: 0, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.42, elbowY: -0.05,
      wristX: 0.28, wristY: -0.35,
      rotation: 0
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },

  // Both palms pressed in center of chest (Namaste)
  PRAYER_CHEST: {
    head: { pitch: 0.08, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0.05 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.26, elbowY: 0.05,
      wristX: -0.03, wristY: 0.12,
      rotation: 0.1
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.26, elbowY: 0.05,
      wristX: 0.03, wristY: 0.12,
      rotation: -0.1
    },
    leftHand: 'PRAYER',
    rightHand: 'PRAYER'
  },

  // Dominant hand at chin (Thank You start)
  CHIN_TOUCH: {
    head: { pitch: 0.02, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.22, elbowY: 0.15,
      wristX: 0.02, wristY: 0.32,
      rotation: 0.3
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },

  // Dominant hand moving forward from chin (Thank You end)
  FORWARD_OUT: {
    head: { pitch: 0.04, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0.03 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.28, elbowY: 0.18,
      wristX: 0.14, wristY: 0.20,
      rotation: 0.1
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'OPEN_FLAT'
  },

  // Both hands palms-up in front of chest (Where / Questions)
  PALMS_UP_SPREAD: {
    head: { pitch: -0.05, yaw: 0, roll: 0.04 },
    torso: { x: 0, y: 0, z: 0, lean: -0.02 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.36, elbowY: 0.10,
      wristX: -0.24, wristY: 0.10,
      rotation: 0.5
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.36, elbowY: 0.10,
      wristX: 0.24, wristY: 0.10,
      rotation: -0.5
    },
    leftHand: 'CUPPED',
    rightHand: 'CUPPED'
  },

  // Fist nodding at chest level (Yes)
  FIST_NOD_HIGH: {
    head: { pitch: 0.05, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.28, elbowY: 0.08,
      wristX: 0.20, wristY: 0.24,
      rotation: 0.2
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'FIST'
  },

  FIST_NOD_LOW: {
    head: { pitch: 0.02, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.28, elbowY: 0.06,
      wristX: 0.20, wristY: 0.12,
      rotation: -0.2
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'FIST'
  },

  // Hand near mouth (Water / Food)
  MOUTH_NEAR: {
    head: { pitch: 0.02, yaw: -0.04, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.24, elbowY: 0.18,
      wristX: 0.08, wristY: 0.34,
      rotation: 0.4
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_W'
  },

  // Raised waving hand at shoulder (Goodbye / Wave)
  HIGH_WAVE_L: {
    head: { pitch: 0, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.36, elbowY: 0.26,
      wristX: 0.28, wristY: 0.46,
      rotation: -0.2
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_B'
  },
  HIGH_WAVE_R: {
    head: { pitch: 0, yaw: 0, roll: 0 },
    torso: { x: 0, y: 0, z: 0, lean: 0 },
    leftArm: {
      shoulderX: -0.32, shoulderY: 0.28,
      elbowX: -0.42, elbowY: -0.05,
      wristX: -0.28, wristY: -0.35,
      rotation: 0
    },
    rightArm: {
      shoulderX: 0.32, shoulderY: 0.28,
      elbowX: 0.36, elbowY: 0.26,
      wristX: 0.36, wristY: 0.46,
      rotation: 0.2
    },
    leftHand: 'OPEN_FLAT',
    rightHand: 'ISL_B'
  }
};
