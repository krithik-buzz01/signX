/**
 * SignX - Handshape Definitions based on Official Indian Sign Language (ISL) Reference
 * Represents finger flexion (0 = extended, 1 = curled/closed) and spread for:
 * [Thumb, Index, Middle, Ring, Pinky]
 */

export const ISL_HANDSHAPES = {
  // Neutral / Base Handshapes
  OPEN_FLAT: {
    name: 'OPEN_FLAT',
    flexion: [0.0, 0.0, 0.0, 0.0, 0.0],
    spread: [0.3, 0.0, 0.0, 0.0, 0.0],
    description: 'Flat open hand with fingers together'
  },
  FIST: {
    name: 'FIST',
    flexion: [1.0, 1.0, 1.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Closed fist with thumb across fingers'
  },
  POINT: {
    name: 'POINT',
    flexion: [1.0, 0.0, 1.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Index finger extended, other fingers closed'
  },
  PRAYER: {
    name: 'PRAYER',
    flexion: [0.0, 0.0, 0.0, 0.0, 0.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Flat fingers pressed firmly together'
  },
  CUPPED: {
    name: 'CUPPED',
    flexion: [0.3, 0.4, 0.4, 0.4, 0.4],
    spread: [0.2, 0.0, 0.0, 0.0, 0.0],
    description: 'Slightly cupped open palm'
  },
  THUMBS_UP: {
    name: 'THUMBS_UP',
    flexion: [0.0, 1.0, 1.0, 1.0, 1.0],
    spread: [0.8, 0.0, 0.0, 0.0, 0.0],
    description: 'Thumb pointing upward with fist'
  },

  // ISL Single Hand English Alphabet (A - Z) Reference Chart
  ISL_A: {
    name: 'ISL_A',
    flexion: [0.1, 0.9, 0.9, 0.9, 0.9],
    spread: [0.2, 0.0, 0.0, 0.0, 0.0],
    description: 'Fist with thumb resting upright alongside index'
  },
  ISL_B: {
    name: 'ISL_B',
    flexion: [0.9, 0.0, 0.0, 0.0, 0.0],
    spread: [-0.2, 0.0, 0.0, 0.0, 0.0],
    description: 'Four upright fingers held together, thumb folded across palm'
  },
  ISL_C: {
    name: 'ISL_C',
    flexion: [0.4, 0.45, 0.45, 0.45, 0.45],
    spread: [0.6, 0.0, 0.0, 0.0, 0.0],
    description: 'Fingers curved forming a distinct C arc'
  },
  ISL_D: {
    name: 'ISL_D',
    flexion: [0.7, 0.0, 0.8, 0.8, 0.8],
    spread: [0.3, 0.0, 0.0, 0.0, 0.0],
    description: 'Index extended straight up, middle/ring/pinky form circle with thumb'
  },
  ISL_E: {
    name: 'ISL_E',
    flexion: [0.85, 0.8, 0.8, 0.8, 0.8],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Fingertips bent down touching thumb folded underneath'
  },
  ISL_F: {
    name: 'ISL_F',
    flexion: [0.7, 0.7, 0.0, 0.0, 0.0],
    spread: [0.2, 0.0, 0.2, 0.2, 0.2],
    description: 'Index and thumb touching in circle, other 3 fingers extended upward'
  },
  ISL_G: {
    name: 'ISL_G',
    flexion: [0.0, 0.0, 1.0, 1.0, 1.0],
    spread: [0.2, 0.0, 0.0, 0.0, 0.0],
    orientation: 'HORIZONTAL',
    description: 'Index finger pointing horizontally, thumb parallel'
  },
  ISL_H: {
    name: 'ISL_H',
    flexion: [0.8, 0.0, 0.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    orientation: 'HORIZONTAL',
    description: 'Index and middle fingers extended together horizontally'
  },
  ISL_I: {
    name: 'ISL_I',
    flexion: [0.9, 1.0, 1.0, 1.0, 0.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Pinky finger extended upright, remaining fingers closed'
  },
  ISL_J: {
    name: 'ISL_J',
    flexion: [0.9, 1.0, 1.0, 1.0, 0.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    motion: 'J_CURVE',
    description: 'Pinky extended tracing a downward J curve in the air'
  },
  ISL_K: {
    name: 'ISL_K',
    flexion: [0.3, 0.0, 0.0, 1.0, 1.0],
    spread: [0.4, 0.15, -0.15, 0.0, 0.0],
    description: 'Index upright, middle forward, thumb resting between them'
  },
  ISL_L: {
    name: 'ISL_L',
    flexion: [0.0, 0.0, 1.0, 1.0, 1.0],
    spread: [0.9, 0.0, 0.0, 0.0, 0.0],
    description: 'Index upright and thumb extended at 90 degrees forming an L'
  },
  ISL_M: {
    name: 'ISL_M',
    flexion: [0.85, 0.7, 0.7, 0.7, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Index, middle, and ring fingers folded over the tucked thumb'
  },
  ISL_N: {
    name: 'ISL_N',
    flexion: [0.85, 0.7, 0.7, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Index and middle fingers folded over the tucked thumb'
  },
  ISL_O: {
    name: 'ISL_O',
    flexion: [0.6, 0.6, 0.6, 0.6, 0.6],
    spread: [0.4, 0.0, 0.0, 0.0, 0.0],
    description: 'All 5 fingertips touching to form an O shape'
  },
  ISL_P: {
    name: 'ISL_P',
    flexion: [0.3, 0.0, 0.0, 1.0, 1.0],
    spread: [0.3, 0.0, 0.0, 0.0, 0.0],
    orientation: 'DOWNWARD',
    description: 'K-handshape oriented pointing downward'
  },
  ISL_Q: {
    name: 'ISL_Q',
    flexion: [0.0, 0.0, 1.0, 1.0, 1.0],
    spread: [0.3, 0.0, 0.0, 0.0, 0.0],
    orientation: 'DOWNWARD',
    description: 'Index and thumb pointing downward'
  },
  ISL_R: {
    name: 'ISL_R',
    flexion: [0.9, 0.0, 0.0, 1.0, 1.0],
    spread: [0.0, 0.05, -0.05, 0.0, 0.0],
    crossed: true,
    description: 'Middle finger crossed over extended index finger'
  },
  ISL_S: {
    name: 'ISL_S',
    flexion: [1.0, 1.0, 1.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Tight fist with thumb folded across front of fingers'
  },
  ISL_T: {
    name: 'ISL_T',
    flexion: [0.6, 0.7, 1.0, 1.0, 1.0],
    spread: [0.2, 0.0, 0.0, 0.0, 0.0],
    description: 'Index finger folded over thumb nestled between index and middle'
  },
  ISL_U: {
    name: 'ISL_U',
    flexion: [0.9, 0.0, 0.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Index and middle fingers extended straight up together'
  },
  ISL_V: {
    name: 'ISL_V',
    flexion: [0.9, 0.0, 0.0, 1.0, 1.0],
    spread: [0.0, 0.25, -0.25, 0.0, 0.0],
    description: 'Index and middle fingers extended apart in a V peace sign'
  },
  ISL_W: {
    name: 'ISL_W',
    flexion: [0.9, 0.0, 0.0, 0.0, 1.0],
    spread: [0.0, 0.2, 0.0, -0.2, 0.0],
    description: 'Index, middle, and ring fingers spread upward in a W shape'
  },
  ISL_X: {
    name: 'ISL_X',
    flexion: [0.9, 0.5, 1.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    description: 'Index finger bent into a hook shape'
  },
  ISL_Y: {
    name: 'ISL_Y',
    flexion: [0.0, 1.0, 1.0, 1.0, 0.0],
    spread: [0.9, 0.0, 0.0, 0.0, 0.6],
    description: 'Thumb and pinky extended wide, middle three fingers closed'
  },
  ISL_Z: {
    name: 'ISL_Z',
    flexion: [0.9, 0.0, 1.0, 1.0, 1.0],
    spread: [0.0, 0.0, 0.0, 0.0, 0.0],
    motion: 'Z_ZIGZAG',
    description: 'Index finger extended tracing a Z path in the air'
  }
};
