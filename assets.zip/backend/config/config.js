/**
 * SignX Backend - Configuration Loader & Validator
 * Securely loads and sanitizes environment variables.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Minimal zero-dependency .env parser
function loadEnvFile() {
  const envPath = path.resolve(__dirname, '../.env');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    content.split('\n').forEach(line => {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
        const idx = trimmed.indexOf('=');
        const key = trimmed.substring(0, idx).trim();
        const value = trimmed.substring(idx + 1).trim().replace(/^['"]|['"]$/g, '');
        if (!process.env[key]) {
          process.env[key] = value;
        }
      }
    });
  }
}

loadEnvFile();

export const config = {
  port: parseInt(process.env.PORT || '3001', 10),
  corsOrigin: process.env.CORS_ORIGIN || '*',
  ollama: {
    baseUrl: (process.env.OLLAMA_BASE_URL || 'https://ollama.com/api').replace(/\/+$/, ''),
    model: process.env.OLLAMA_MODEL || 'qwen3:8b',
    apiKey: process.env.OLLAMA_API_KEY || '',
    timeoutMs: parseInt(process.env.OLLAMA_TIMEOUT_MS || '12000', 10),
    maxRetries: parseInt(process.env.OLLAMA_MAX_RETRIES || '2', 10)
  }
};

/**
 * Returns safe metadata without leaking API keys or credentials
 */
export function getSanitizedConfig() {
  const maskedKey = config.ollama.apiKey
    ? `${config.ollama.apiKey.substring(0, 4)}...${config.ollama.apiKey.slice(-4)}`
    : 'NOT_SET';

  return {
    port: config.port,
    corsOrigin: config.corsOrigin,
    ollama: {
      baseUrl: config.ollama.baseUrl,
      model: config.ollama.model,
      apiKeyConfigured: Boolean(config.ollama.apiKey),
      apiKeyMasked: maskedKey,
      timeoutMs: config.ollama.timeoutMs,
      maxRetries: config.ollama.maxRetries
    }
  };
}
