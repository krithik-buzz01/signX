/**
 * SignX Backend - HTTP Server Entry Point
 * Lightweight, zero-dependency, secure HTTP server for Chrome Extension integration.
 */

import http from 'http';
import { config, getSanitizedConfig } from './config/config.js';
import { SignToTextRouter } from './routes/sign-to-text-router.js';

function setCorsHeaders(res, origin) {
  res.setHeader('Access-Control-Allow-Origin', origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  res.setHeader('Access-Control-Max-Age', '86400');
}

export function createServer() {
  return http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    setCorsHeaders(res, origin);

    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    // Set JSON content-type default
    res.setHeader('Content-Type', 'application/json; charset=utf-8');

    // Route: GET /api/health
    if (req.method === 'GET' && (pathname === '/api/health' || pathname === '/health')) {
      const result = await SignToTextRouter.handleHealth();
      res.writeHead(result.statusCode);
      res.end(JSON.stringify(result.body, null, 2));
      return;
    }

    // Route: GET /api/config (Sanitized only)
    if (req.method === 'GET' && pathname === '/api/config') {
      res.writeHead(200);
      res.end(JSON.stringify({ status: 'success', config: getSanitizedConfig() }, null, 2));
      return;
    }

    // Route: POST /api/sign-to-text
    if (req.method === 'POST' && pathname === '/api/sign-to-text') {
      let rawBody = '';
      const maxBytes = 1024 * 1024; // 1MB limit

      req.on('data', chunk => {
        rawBody += chunk;
        if (rawBody.length > maxBytes) {
          res.writeHead(413);
          res.end(JSON.stringify({ error: 'Payload too large (1MB max)' }));
          req.destroy();
        }
      });

      req.on('end', async () => {
        let parsed = null;
        try {
          parsed = rawBody ? JSON.parse(rawBody) : {};
        } catch (e) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Invalid JSON payload format' }));
          return;
        }

        try {
          const result = await SignToTextRouter.handleSignToText(parsed);
          res.writeHead(result.statusCode);
          res.end(JSON.stringify(result.body, null, 2));
        } catch (err) {
          console.error('[SignX Server Error]', err);
          res.writeHead(500);
          res.end(JSON.stringify({ error: 'Internal Server Error', message: err.message }));
        }
      });
      return;
    }

    // 404 Fallback
    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Not Found', path: pathname }));
  });
}

// Start standalone if executed directly
if (process.argv[1] && process.argv[1].endsWith('server.js')) {
  const server = createServer();
  const PORT = config.port;

  server.listen(PORT, () => {
    console.log('====================================================');
    console.log(`🚀 SignX Backend Service running on port ${PORT}`);
    console.log(`📡 Health Check: http://localhost:${PORT}/api/health`);
    console.log(`✍ Sign to Text: POST http://localhost:${PORT}/api/sign-to-text`);
    console.log(`🔒 Security: API Key is securely held on backend only.`);
    console.log(`🤖 Model: ${config.ollama.model} (${config.ollama.baseUrl})`);
    console.log('====================================================');
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log('\nGracefully shutting down SignX backend...');
    server.close(() => {
      console.log('Server closed. Goodbye!');
      process.exit(0);
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
