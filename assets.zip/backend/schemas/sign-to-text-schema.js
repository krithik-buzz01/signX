/**
 * SignX Backend - Request & Response Schemas / Validators
 * Validates sign token inputs and structured text outputs.
 */

export class SignToTextSchema {
  /**
   * Validate and sanitize incoming request payload
   * @param {any} body 
   * @returns {{ valid: boolean, sanitized?: { tokens: string[], confidence: number, rawText: string }, error?: string }}
   */
  static validateRequest(body) {
    if (!body || typeof body !== 'object') {
      return { valid: false, error: 'Request body must be a JSON object.' };
    }

    let tokens = [];

    if (Array.isArray(body.tokens)) {
      tokens = body.tokens
        .map(t => (typeof t === 'string' ? t.trim() : ''))
        .filter(t => t.length > 0);
    } else if (typeof body.rawText === 'string' && body.rawText.trim()) {
      tokens = body.rawText.trim().split(/\s+/).filter(Boolean);
    }

    if (tokens.length === 0) {
      return { valid: false, error: 'Request must include a non-empty array of recognized tokens or rawText.' };
    }

    // Sanitize token contents (remove control characters / limit length)
    tokens = tokens.map(t => t.replace(/[^\w\s\?\-\,\.\!\'\"]/gi, '').slice(0, 50));

    // Clamp confidence between 0.0 and 1.0
    let confidence = 1.0;
    if (typeof body.confidence === 'number' && !isNaN(body.confidence)) {
      confidence = Math.max(0.0, Math.min(1.0, body.confidence));
    }

    const rawText = typeof body.rawText === 'string' ? body.rawText.trim() : tokens.join(' ');

    return {
      valid: true,
      sanitized: {
        tokens,
        confidence,
        rawText
      }
    };
  }

  /**
   * Format structured output adhering to SignX contract
   */
  static formatResponse({ recognizedTokens, displayText, confidence, status = 'success', source = 'ollama_cloud', model = 'qwen3:8b', latencyMs = 0, error = null }) {
    return {
      recognized_tokens: recognizedTokens || [],
      display_text: displayText || (recognizedTokens ? recognizedTokens.join(' ') : ''),
      confidence: typeof confidence === 'number' ? Number(confidence.toFixed(2)) : 1.0,
      status: status,
      source: source,
      model: model,
      latency_ms: latencyMs,
      ...(error ? { error } : {})
    };
  }
}
