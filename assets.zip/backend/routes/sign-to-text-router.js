/**
 * SignX Backend - Sign-to-Text API Router
 * Dispatches sign token synthesis requests and reports system health.
 */

import { SignToTextSchema } from '../schemas/sign-to-text-schema.js';
import { ollamaService } from '../services/ollama_service.js';
import { getSanitizedConfig } from '../config/config.js';

export class SignToTextRouter {
  /**
   * Handle POST /api/sign-to-text
   */
  static async handleSignToText(reqBody) {
    // 1. Validate incoming request
    const validation = SignToTextSchema.validateRequest(reqBody);
    if (!validation.valid) {
      return {
        statusCode: 400,
        body: SignToTextSchema.formatResponse({
          status: 'error',
          error: validation.error
        })
      };
    }

    const { tokens, confidence, rawText } = validation.sanitized;

    try {
      // 2. Synthesize via Ollama Cloud service
      const response = await ollamaService.synthesizeTokens(tokens, confidence);
      return {
        statusCode: 200,
        body: response
      };
    } catch (err) {
      // 3. Graceful error response (permits client-side fallback)
      return {
        statusCode: 502,
        body: SignToTextSchema.formatResponse({
          recognizedTokens: tokens,
          displayText: rawText,
          confidence,
          status: 'error',
          source: 'backend_service_error',
          error: `Ollama Cloud processing failed: ${err.message}`
        })
      };
    }
  }

  /**
   * Handle GET /api/health
   */
  static async handleHealth() {
    const health = await ollamaService.checkHealth();
    return {
      statusCode: 200,
      body: {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'SignX Sign-to-Text Backend',
        version: '1.0.0',
        config: getSanitizedConfig(),
        ollamaConnectivity: health
      }
    };
  }
}
