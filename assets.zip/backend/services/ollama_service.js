/**
 * SignX Backend - Ollama Cloud & LLM Service
 * Communicates with Ollama Cloud API with strict anti-hallucination constraints,
 * retry logic, timeout handling, and secure authentication without key leakage.
 */

import { config, getSanitizedConfig } from '../config/config.js';
import { SignToTextSchema } from '../schemas/sign-to-text-schema.js';

const SYSTEM_PROMPT = `You are the SignX Indian Sign Language (ISL) to English text synthesizer.
Your ONLY role is to convert a sequence of recognized ISL sign tokens into a smooth, natural English sentence.

CRITICAL CONSTRAINTS & RULES:
1. PRESERVE MEANING: Accurately reflect ONLY the meaning of the given recognized sign tokens.
2. DO NOT ADD FACTS: Never invent details, names, locations, actions, or adjectives that are not in the sign tokens.
3. DO NOT INVENT SIGNS: Use strictly the tokens provided.
4. PRESERVE AMBIGUITY & UNCERTAINTY: If tokens are incomplete or ambiguous, output the most direct literal grammatical smoothing without guessing extra narrative context.
5. NO HALLUCINATION: If there is insufficient information, return the simplest natural formulation of the available tokens.
6. OUTPUT FORMAT: Output ONLY the final plain text English sentence. Do NOT include quotes, explanations, markdown fences, or conversational commentary.`;

export class OllamaService {
  constructor(customConfig = {}) {
    this.baseUrl = customConfig.baseUrl || config.ollama.baseUrl;
    this.model = customConfig.model || config.ollama.model;
    this.apiKey = customConfig.apiKey !== undefined ? customConfig.apiKey : config.ollama.apiKey;
    this.timeoutMs = customConfig.timeoutMs || config.ollama.timeoutMs;
    this.maxRetries = customConfig.maxRetries || config.ollama.maxRetries;
  }

  /**
   * Log safe debug message without leaking credentials
   */
  log(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const safeMeta = { ...meta };
    // Redact any potential secrets
    ['apiKey', 'authorization', 'key', 'secret', 'token'].forEach(k => {
      if (safeMeta[k]) safeMeta[k] = '[REDACTED]';
    });
    console[level](`[${timestamp}] [OllamaService:${level.toUpperCase()}] ${message}`, Object.keys(safeMeta).length ? safeMeta : '');
  }

  /**
   * Synthesizes recognized sign tokens into a natural English sentence
   * @param {string[]} tokens - Array of recognized sign tokens
   * @param {number} confidence - Recognition confidence
   * @returns {Promise<object>} Structured response
   */
  async synthesizeTokens(tokens, confidence = 1.0) {
    const startTime = Date.now();
    const tokenString = tokens.join(' ');
    
    this.log('info', `Synthesizing ${tokens.length} tokens with model: ${this.model}`, {
      tokens,
      confidence
    });

    let attempt = 0;
    let lastError = null;

    while (attempt <= this.maxRetries) {
      attempt++;
      try {
        const text = await this.callOllamaApi(tokenString);
        const latencyMs = Date.now() - startTime;
        
        // Post-process & clean response
        const cleanedText = this.cleanOutput(text, tokens);

        this.log('info', `Synthesis successful in ${latencyMs}ms`, {
          model: this.model,
          latencyMs
        });

        return SignToTextSchema.formatResponse({
          recognizedTokens: tokens,
          displayText: cleanedText,
          confidence,
          status: 'success',
          source: 'ollama_cloud',
          model: this.model,
          latencyMs
        });
      } catch (err) {
        lastError = err;
        this.log('warn', `Ollama request attempt ${attempt} failed: ${err.message}`, {
          attempt,
          maxRetries: this.maxRetries
        });

        if (attempt <= this.maxRetries) {
          // Exponential backoff
          const delay = Math.pow(2, attempt) * 250;
          await new Promise(r => setTimeout(r, delay));
        }
      }
    }

    // If all retries failed, log and rethrow or return structured error
    this.log('error', `All Ollama requests failed after ${this.maxRetries + 1} attempts: ${lastError.message}`);
    throw lastError;
  }

  /**
   * Execute HTTP request to Ollama endpoint
   */
  async callOllamaApi(tokenString) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      };

      if (this.apiKey) {
        headers['Authorization'] = `Bearer ${this.apiKey}`;
      }

      // Format payload for Ollama /api/chat or OpenAI-compatible /v1/chat/completions
      const isV1 = this.baseUrl.endsWith('/v1') || this.baseUrl.includes('openai');
      const endpoint = isV1 
        ? `${this.baseUrl}/chat/completions` 
        : `${this.baseUrl}/chat`;

      const body = {
        model: this.model,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: `Recognized ISL Sign Tokens: ${tokenString}` }
        ],
        stream: false,
        options: {
          temperature: 0.1,
          top_p: 0.9
        }
      };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: controller.signal
      });

      clearTimeout(timer);

      if (!response.ok) {
        const errorBody = await response.text().catch(() => '');
        throw new Error(`Ollama API error (${response.status} ${response.statusText}): ${errorBody}`);
      }

      const json = await response.json();
      
      // Extract content from response
      const messageContent = json.message?.content || 
                             json.choices?.[0]?.message?.content || 
                             json.response || '';

      if (!messageContent.trim()) {
        throw new Error('Ollama returned empty response content.');
      }

      return messageContent.trim();
    } catch (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') {
        throw new Error(`Ollama request timed out after ${this.timeoutMs}ms`);
      }
      throw err;
    }
  }

  /**
   * Cleans output and ensures strict adherence to non-hallucination rules
   */
  cleanOutput(rawText, originalTokens) {
    if (!rawText) return originalTokens.join(' ');

    // Strip markdown code fences, prefixes like "English sentence: ", quotes
    let text = rawText
      .replace(/^```[a-z]*\s*/i, '')
      .replace(/\s*```$/i, '')
      .replace(/^(English\s*Translation|English\s*Sentence|ISL\s*to\s*English|Sentence|Output)\s*:\s*/i, '')
      .replace(/^["']|["']$/g, '')
      .trim();

    // Ensure first character is capitalized and ending punctuation exists
    if (text.length > 0) {
      text = text.charAt(0).toUpperCase() + text.slice(1);
      if (!/[.!?]$/.test(text)) {
        // If question token existed, add question mark
        const hasQuestion = originalTokens.some(t => 
          ['WHERE', 'WHAT', 'WHO', 'WHY', 'HOW', 'WHEN', 'WHICH'].includes(t.toUpperCase())
        );
        text += (hasQuestion ? '?' : '.');
      }
    }

    return text;
  }

  /**
   * Health check to test backend Ollama connectivity
   */
  async checkHealth() {
    try {
      const isV1 = this.baseUrl.endsWith('/v1');
      const url = isV1 ? `${this.baseUrl}/models` : `${this.baseUrl}/tags`;
      const headers = {};
      if (this.apiKey) headers['Authorization'] = `Bearer ${this.apiKey}`;

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(url, { headers, signal: controller.signal });
      clearTimeout(timer);

      return {
        reachable: res.ok,
        status: res.status,
        model: this.model,
        baseUrl: this.baseUrl
      };
    } catch (err) {
      return {
        reachable: false,
        error: err.message,
        model: this.model,
        baseUrl: this.baseUrl
      };
    }
  }
}

export const ollamaService = new OllamaService();
